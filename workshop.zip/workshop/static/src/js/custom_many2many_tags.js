odoo.define("workshop.custom_many2many_tags", function(require){

    var core = require('web.core');
    var AbstractField = require('web.AbstractField');
    var fieldRegistry = require('web.field_registry');
    var relationalFields = require('web.relational_fields');
    var FieldMany2ManyTags = relationalFields.FieldMany2ManyTags;
    var qweb = core.qweb;

    var CustomMany2ManyTags = FieldMany2ManyTags.extend({
        tag_template: "CustomMany2ManyTag",
        events: _.extend({}, AbstractField.prototype.events, {
            'click .o_delete': '_onDeleteTag', /*'_onDeleteTagExtend',*/
        }),
        fieldsToFetch: {
            display_name: {type: 'char'},
            is_used: {type: 'boolean'}
        },

        _onDeleteTag: function (event) {
            event.preventDefault();
            event.stopPropagation();
            this._removeTag($(event.target).parent().data('id'));
        },

        _onDeleteTagExtend: function (event) {
            console.log("_onDeleteTagExtend");
        },

        _getRenderTagsContext: function () {
            var elements = this.value ? _.pluck(this.value.data, 'data') : [];
            // console.log("elements: ", elements);
            return {
                colorField: this.colorField,
                elements: elements,
                hasDropdown: this.hasDropdown,
                readonly: this.mode === "readonly",
            };
        },

        _renderReadonly: function () {
            this._renderTags();
        },

        _renderTags: function () {
            this.$el.html(qweb.render(this.tag_template, this._getRenderTagsContext()));
        },
    });
    fieldRegistry.add('custom_many2many_tags', CustomMany2ManyTags);

    return {
        CustomMany2ManyTags: CustomMany2ManyTags,
    }

});
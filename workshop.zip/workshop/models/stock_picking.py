# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class StockPicking(models.Model):
    _inherit = "stock.picking"

    is_used = fields.Boolean(default=False)
    is_received = fields.Boolean(
        default=False, compute="_compute_is_received", store=True
    )

    worksheet_id = fields.Many2one('car.workshop', string="Worksheet")

    def _compute_vehicle(self):
        for record in self:
            if record.id:
                get_worksheet_vehicle = self.env["car.workshop"].sudo().search([("name", "=", record.origin)],limit=1)
                # Set vehicle_ids based on the condition
                record.vehicle_ids = get_worksheet_vehicle.mapped('vehicle_id')
            else:
                # Set vehicle_id to False if condition is not met
                record.vehicle_ids = False
    vehicle_ids = fields.Many2one("fleet.vehicle", string="Vehicle", index=True, compute=_compute_vehicle, store=True)
    vehicle_id = fields.Many2one("fleet.vehicle", string="Vehicle", index=True)

    @api.model
    def update_vehicle_id_on_out_records(self):
        missing_vehicle_out_records = self.search([("vehicle_id","=",False),("move_type","=","one")])

        for record in missing_vehicle_out_records:
            origin_worksheet = self.env["car.workshop"].sudo().search([("name", "=", record.origin)],limit=1)
            record.vehicle_id = origin_worksheet.vehicle_id
    
    @api.depends("state")
    def _compute_is_received(self):
        for picking in self:
            if picking.state == "done":
                picking.is_received = True

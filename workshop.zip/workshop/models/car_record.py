from odoo import models, fields
from dataclasses import dataclass
from typing import Optional

@dataclass
class RecordData:
    worksheet_id : int
    vehicle_id : int
    stage_id : Optional[int]
    state_id : int

class CarRecord(models.Model):
    _name = "car.record"
    _description = "Record of Cars State Changes"

    worksheet_id = fields.Many2one(comodel_name='car.workshop', string='Worksheet')
    vehicle_id = fields.Many2one(comodel_name='fleet.vehicle', string="Vehicle")
    stage_id = fields.Many2one(comodel_name='worksheet.stages', string="Worksheet Stage")
    state_id = fields.Many2one(comodel_name='fleet.vehicle.state', string="Vehicle State")

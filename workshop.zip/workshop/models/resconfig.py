# -*- coding: utf-8 -*-
from odoo import fields, models, api
import json


class WorkshopSetting(models.TransientModel):
    _inherit = "res.config.settings"

    invoice_journal_type = fields.Many2one(
        "account.journal",
        string="Car Workshop Journal",
        config_parameter="workshop.invoice_journal_type",
    )
    save_by_backdate = fields.Boolean(
        "Backdate", config_parameter="workshop.save_by_backdate"
    )


class WorksheetStages(models.Model):
    _name = "worksheet.stages"
    _description = "worksheet Stage"
    _order = "sequence"

    def _get_default_vehicle_ids(self):
        default_vehicle_id = self.env["fleet.vehicle"].browse(
            self._context.get("active_id")
        )
        return [default_vehicle_id] if default_vehicle_id else None

    name = fields.Char(string="Stage Name", required=True)
    description = fields.Text(string="Description", translate=True)
    sequence = fields.Integer(string="Sequence")
    vehicle_ids = fields.Many2many(
        "fleet.vehicle",
        "worksheet_type_rel",
        "type_id",
        "vehicle_id",
        string="Vehicles",
        default=_get_default_vehicle_ids,
    )
    fold = fields.Boolean(
        "Folded in Tasks Pipeline",
        help="This stage is folded in the kanban view when "
        "there are no records in that stage to display.",
    )
    finishing_state = fields.Boolean(string="Finishing State", default=False)

    _sql_constraints = [
        ("worksheet_stage_name_unique", "unique(name)", "Stage name already exists")
    ]


class PlannedWork(models.Model):
    _name = "planned.work"
    invoice_done = fields.Boolean(string="Invoice Completed")

    invoice_select = fields.Boolean(string="Invoice Type")
    planned_work = fields.Many2one(
        "product.product", string="Planned work", domain=[("type", "=", "service")]
    )
    time_spent = fields.Float(string="Estimated Time")
    work_date = fields.Datetime(string="From Date")  # Date of work planned:planned date
    # start_date = fields.Datetime(string='From Date', compute="compute_start_date", store=True)
    end_date = fields.Datetime(string="To Date")
    responsible = fields.Many2one("res.users", string="Responsible")
    work_id = fields.Many2one("car.workshop", string="Work id")
    work_cost = fields.Float(string="Service Cost")
    completed = fields.Boolean(string="Completed")
    duration = fields.Float(string="Duration")
    work_date2 = fields.Datetime(
        string="Date"
    )  # Date of work completed/done:completed date

    @api.onchange("planned_work")
    def get_price(self):
        self.work_cost = self.planned_work.lst_price


class MaterialUsed(models.Model):
    _name = "material.used"

    invoice_done = fields.Boolean(string="Invoice Completed")
    invoice_select = fields.Boolean(string="Invoice Type")
    material = fields.Many2one("product.product", string="Products")
    amount = fields.Float(string="Quantity")
    price = fields.Float(string="Unit Price")
    material_id = fields.Many2one("car.workshop")
    location_src_id = fields.Many2one(
        "stock.location",
        "Custom Source Location",
    )
    location_domain = fields.Char(
        compute="_compute_field1_field2_location_domain",
        readonly=True,
        store=False,
    )
    picking_id = fields.Many2one("stock.picking", string="Picking ID", compute="_compute_picking_id")
    invoice_id = fields.Many2one("account.move", string="Invoice ID", compute="_compute_invoice_id")
    invoice_line_ids = fields.One2many("account.move.line", "material_used_id")

    @api.depends("material")
    def _compute_field1_field2_location_domain(self):
        # Define your logic here to compute the domain
        for rec in self:
            locations_id = []
            locations_stock_quant = self.env["stock.quant"].search(
                [("product_id", "=", rec.material.id), ("quantity", ">", 0)]
            )
            for location in locations_stock_quant:
                locations_id.append(location.location_id.id)

            domain = [("id", "in", locations_id), ("usage", "=", "internal")]
            rec.location_domain = json.dumps(domain)

    @api.depends("material_id")
    def _compute_picking_id(self):
        for record in self:
            worksheet = record.material_id
            material_picking_id = False
            for picking_id in worksheet.picking_ids:
                for line in picking_id.move_ids_without_package:
                    if record.material.id == line.product_id.id:
                        material_picking_id = picking_id.id
                        break
            record.picking_id = material_picking_id
            

    @api.depends("material_id")
    def _compute_invoice_id(self):
        for record in self:
            worksheet = self.material_id
            material_invoice_id = False
            posted_invoices = self.env["account.move"].search([
                ("vehicle_id", "=", worksheet.vehicle_id.id),
                ('state','=','posted'),
                ('move_type','=','out_invoice')
            ])
            for invoice in posted_invoices:
                for invoice_line in invoice.invoice_line_ids:
                    if record.material.id == invoice_line.product_id.id:
                        material_invoice_id = invoice.id
                        break
            record.invoice_id = material_invoice_id

import json
from datetime import datetime, date
import requests
import base64
from dateutil.parser import parse as duparse
from odoo import api, fields, models, _
from odoo.exceptions import Warning
from odoo.exceptions import UserError, ValidationError

import logging

_logger = logging.getLogger(__name__)


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    material_used_id = fields.Many2one(
        "material.used", String="Material Used", ondelete="set null"
    )

    picking_id = fields.Many2one(
        comodel_name="stock.picking", string="Picking", ondelete="set null"
    )

    # vehicle_id = fields.Many2one( comodel_name='fleet.vehicle', string='Vehicle', related='move_id.vehicle_id', ondelete="set null")

    vehicle_ids = fields.Many2one('fleet.vehicle', string='Vehicle', compute="compute_vehicle",)

    @api.depends('move_id')
    def compute_vehicle(self):

        for record in self:
            if record.move_id and record.move_id.state == 'posted':
                # Set vehicle_id based on the condition
                record.vehicle_ids = record.move_id.vehicle_id.id
            else:
                # Set vehicle_id to False if condition is not met
                record.vehicle_ids = False


class AccountMove(models.Model):
    _inherit = "account.move"

    sale_order_id = fields.Many2one(
        "sale.order",
        string="Sale Order",
        domain="[('state', '=', 'sale'), ('invoice_status', 'in', ['to invoice', 'no']), ('is_used', '=', False),"
        "('partner_id', '=', partner_id)]",
        readonly=True,
        states={"draft": [("readonly", False)]},
        ondelete="restrict",
    )

    vehicle_id = fields.Many2one(
        "fleet.vehicle",
        string="Vehicle",
        readonly=True,
        states={"draft": [("readonly", False)]},
        ondelete="restrict",
    )
    purchase_order_id = fields.Many2one("purchase.order", string="Purchase Order ID")
    picking_id = fields.Many2one("stock.picking", string="Stock Picking")
    # picking_ids = fields.Many2many("stock.picking", string="Stock Picking")

    validation_text = fields.Char("Validation Text", default="")

    @api.onchange("sale_order_id")
    def _onchange_sale_order_id(self):
        if self.sale_order_id:
            self.invoice_line_ids = [(5, 0, 0)]
            sale_order_lines = self.sale_order_id.order_line
            invoice_lines_data = []
            lines_data = []
            for line in sale_order_lines:
                prod_sale_account = False
                if line.product_id.property_account_income_id:
                    income_account = line.product_id.property_account_income_id.id
                else:
                    income_account = (
                        line.product_id.categ_id.property_account_income_categ_id.id
                    )

                invoice_lines_data.append(
                    (
                        0,
                        0,
                        {
                            "name": line.product_id.name,
                            "account_id": income_account,
                            "price_unit": line.price_unit,
                            "quantity": line.product_uom_qty,
                            "product_id": line.product_id.id,
                            "price_subtotal": line.price_subtotal,
                            "date": date.today(),
                            "tax_ids": line.tax_id or "",
                            "currency_id": line.currency_id.id,
                            "credit": line.price_unit,
                        },
                    )
                )
            self.invoice_line_ids = invoice_lines_data
            self._onchange_invoice_line_ids()

    def _check_stockmove(self, picking_id: int) -> models.Model:
        return self.env["stock.move"].sudo().search([("picking_id", "=", picking_id)])

    def _action_workshop_stockmove(self, sale_order: models.Model) -> None:
        picking = (
            self.env["stock.picking"].sudo().search([("origin", "=", sale_order.name)])
        )
        if picking:
            if self.vehicle_id:
                picking.vehicle_id = self.vehicle_id.id
            ws_moves = self._check_stockmove(picking.id)
            if ws_moves:
                for ws_move in ws_moves:
                    ws_move.quantity_done = ws_move.product_uom_qty
                    ws_move._action_done()

    def action_post(self):
        # import pdb; pdb.set_trace()
        result = super(AccountMove, self).action_post()
        if self.sale_order_id:
            workshop = (
                self.env["sale.order"]
                .sudo()
                .search([("id", "=", self.sale_order_id.id)])
            )
            if workshop:
                if self.ref:
                    workshop.write({"workshop_ids": self.ref})
                # self._action_workshop_stockmove(workshop)
                workshop.write({"is_used": True, "invoice_status": "invoiced"})
                for order_line in workshop.order_line:
                    order_line.qty_invoiced += 1.0

            if self.vehicle_id and self.env["sale.order"].verify_module():
                workshop.write({"vehicle_id": self.vehicle_id})

            if self.ref:
                worksheet_id = (
                    self.env["car.workshop"].sudo().search([("id", "=", self.ref)])
                )
                if worksheet_id.materials_used:
                    for materials_used in worksheet_id.materials_used:
                        if (
                            materials_used.invoice_select
                            and not materials_used.invoice_done
                        ):
                            materials_used.write({"invoice_done": True})
                if worksheet_id.planned_works:
                    for planned_works in worksheet_id.planned_works:
                        if (
                            planned_works.invoice_select
                            and not planned_works.invoice_done
                        ):
                            planned_works.write({"invoice_done": True})

        if self.picking_id:
            self.picking_id.is_used = True

        move_lines = []
        move_id = self.env["stock.picking"]
        vals = {}

        for line in self.invoice_line_ids:
            if line.material_used_id:
                company_id = (
                    self.env.context.get("company_id") or self.env.user.company_id.id
                )
                types = self.env["stock.picking.type"].search(
                    [
                        ("code", "=", "outgoing"),
                        ("warehouse_id.company_id", "=", company_id),
                    ],
                    limit=1,
                )
                material_used_line = self.env["material.used"].search(
                    [("id", "=", line.material_used_id.id)]
                )
                vals = {
                    "partner_id": material_used_line.material_id.partner_id.id,
                    "origin": material_used_line.material_id.name,
                    "move_type": "one",
                    "picking_type_id": types.id,
                    "location_id": material_used_line.location_src_id.id,
                    "location_dest_id": material_used_line.material_id.partner_id.property_stock_customer.id,
                    "vehicle_id": self.vehicle_id.id,
                }

                move_line = (
                    0,
                    0,
                    {
                        "name": material_used_line.material_id.name,
                        "product_id": material_used_line.material.id,
                        "product_uom": material_used_line.material.uom_id.id,
                        "product_uom_qty": material_used_line.amount,
                        "quantity_done": material_used_line.amount,
                        "location_id": material_used_line.location_src_id.id,
                        "location_dest_id": material_used_line.material_id.partner_id.property_stock_customer.id,
                    },
                )
                move_lines.append(move_line)
            if line.picking_id:
                line.picking_id.is_used = True
        if move_lines != []:
            vals.update({"move_lines": move_lines})

            if self.sale_order_id:
                so_id = (
                    self.env["sale.order"]
                    .sudo()
                    .search([("id", "=", self.sale_order_id.id)])
                )
                if so_id and so_id.vehicle_id:
                    vals.update({"vehicle_id": so_id.vehicle_id.id})

            move = move_id.create(vals)
            move.action_confirm()
            move.action_assign()
            move._action_done()
        return result

    # for Sale Receipt
    def check_confirm(self):
        validation_texts = []
        for record in self:
            product_lines = record.invoice_line_ids

            for line in product_lines:
                if line.product_id:
                    product = line.product_id
                    branch = record.branch_id.display_name
                    min_quantity = 0
                    max_quantity = 0

                    if product.qty_available:
                        on_hand = product.qty_available

                        orderpoint = self.env["stock.warehouse.orderpoint"].search(
                            [
                                ("product_id", "=", product.id),
                                ("location_id", "=like", "%" + branch + "%"),
                            ]
                        )
                        if not orderpoint:
                            location = record.company_id.location_id
                            orderpoint = self.env["stock.warehouse.orderpoint"].search(
                                [
                                    ("product_id", "=", product.id),
                                    ("location_id", "=", location.id),
                                ],
                                limit=1,
                            )
                        min_quantity = orderpoint.product_min_qty
                        max_quantity = orderpoint.product_max_qty

                        if not min_quantity < 0 and not max_quantity < 0:
                            # if on_hand < min_quantity:
                            #     validation_texts.append(
                            #         "- "
                            #         + product.display_name
                            #         + " is below its minimum level."
                            #     )
                            if on_hand > max_quantity:
                                validation_texts.append(
                                    "- "
                                    + product.display_name
                                    + " is above its maximum level."
                                )

            if len(validation_texts) > 0:
                record.validation_text = ""
                for validation_text in validation_texts:
                    record.validation_text = (
                        record.validation_text + validation_text + "\n"
                    )

                validation_form = self.env.ref(
                    "workshop.account_move_validation_popup_form"
                )
                popup = {
                    "name": _("Confirmation"),
                    "type": "ir.actions.act_window",
                    "view_mode": "form",
                    "view_id": validation_form.id,
                    "res_model": "account.move",
                    "res_id": self.id,
                    "target": "new",
                }
                return popup
            else:
                return self.action_post()

    def button_draft(self):
        # OVERRIDE to update the Sale Order
        res = super(AccountMove, self).button_draft()
        for move in self:
            if move.sale_order_id:
                move.sale_order_id.write(
                    {"is_used": False, "invoice_status": "to invoice"}
                )
        return res

    def write(self, vals):
        result = super(AccountMove, self).write(vals)
        if self.sale_order_id:
            for order_line in self.sale_order_id.order_line:
                order_line.qty_invoiced += 1.0
        return result

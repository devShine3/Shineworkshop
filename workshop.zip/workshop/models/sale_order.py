from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = "sale.order"

    workshop_ids = fields.Many2one("car.workshop", string="Workshops")
    is_used = fields.Boolean(default=False)

    def verify_module(self):
        so_inherit_mod = self.env["ir.module.module"].search(
            [("name", "=", "saleorder_inherit")]
        )
        is_installed = False
        if so_inherit_mod and so_inherit_mod.state == "installed":
            is_installed = True
        return is_installed

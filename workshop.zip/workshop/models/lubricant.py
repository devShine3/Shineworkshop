from odoo import models, fields


class Lubricant(models.Model):
    _inherit = "fleet.vehicle.odometer"
    _description = "Fleet Lubricant"

    due_date = fields.Date(string="Due Date")

from odoo import models, fields, _


class StockPickingInherit(models.Model):
    _inherit = "stock.picking"

    validation_text = fields.Char("Validation Text", default="")

    # for Delivery Order, Purchase Order, Sale Order, Receipt
    def check_validation(self):
        is_internal = False
        internal_transfers = self.env['stock.picking.type'].search([
            ('code','=','internal')
        ])
        for transfer in internal_transfers:
            if transfer.id == self.picking_type_id.id:
                is_internal = True

        if is_internal == False:
            validation_texts = []
            for record in self:
                product_lines = record.move_line_ids_without_package
                location = record.location_id

                for line in product_lines:
                    if line.product_id:
                        product = line.product_id
                        # location = line.location_id
                        on_hand = 0
                        min_quantity = 0
                        max_quantity = 0
                        quantity_done = line.qty_done

                        # if product.qty_available:
                        orderpoint = self.env["stock.warehouse.orderpoint"].search(
                            [
                                ("product_id", "=", product.id),
                                ("location_id", "=", location.id),
                            ]
                        )
                        if not orderpoint:
                            # location = record.company_id.location_id
                            location = record.location_dest_id
                            orderpoint = self.env["stock.warehouse.orderpoint"].search(
                                [
                                    ("product_id", "=", product.id),
                                    ("location_id", "=", location.id),
                                ], limit=1
                            )
                        
                        if orderpoint:
                            stock_quants = self.env["stock.quant"].search(
                                [
                                    ("product_id", "=", product.id),
                                    ("location_id", "=", location.id),
                                ]
                            )
                            total_on_hand = 0
                            if stock_quants:
                                for stock_quant in stock_quants:
                                    total_on_hand = total_on_hand + stock_quant.quantity
                                on_hand = total_on_hand
                            min_quantity = orderpoint.product_min_qty
                            max_quantity = orderpoint.product_max_qty

                            # if not min_quantity < 0 and not max_quantity < 0:
                            delivery_type = record.picking_type_code
                            if delivery_type == "outgoing":
                                on_hand = on_hand - quantity_done
                                if on_hand < min_quantity:
                                    validation_texts.append(
                                        "- "
                                        + product.display_name
                                        + " is below its minimum level."
                                    )
                            elif delivery_type == "incoming":
                                on_hand = on_hand + quantity_done
                                if on_hand > max_quantity:
                                    validation_texts.append(
                                        "- "
                                        + product.display_name
                                        + " is above its maximum level."
                                    )

                if len(validation_texts) > 0:
                    record.validation_text = ""
                    for validation_text in validation_texts:
                        record.validation_text = (
                            record.validation_text + validation_text + "\n"
                        )

                    validation_form = self.env.ref(
                        "workshop.delivery_order_validation_popup_form"
                    )
                    popup = {
                        "name": _("Confirmation"),
                        "type": "ir.actions.act_window",
                        "view_mode": "form",
                        "view_id": validation_form.id,
                        "res_model": "stock.picking",
                        "res_id": self.id,
                        "target": "new",
                    }
                    return popup
                else:
                    return self.button_validate()
        else:
            return self.button_validate()


class StockPickingReturnInherit(models.TransientModel):
    _inherit = "stock.return.picking"

    validation_text = fields.Char("Validation Text", default="")

    # for Purchase Return and Sale Return
    def check_return(self):
        validation_texts = []
        for record in self:
            product_lines = record.product_return_moves

            for line in product_lines:
                if line.product_id:
                    product = line.product_id
                    location = record.location_id
                    min_quantity = 0
                    max_quantity = 0

                    if product.qty_available:
                        on_hand = product.qty_available

                        orderpoint = self.env["stock.warehouse.orderpoint"].search(
                            [
                                ("product_id", "=", product.id),
                                ("location_id", "=", location.id),
                            ]
                        )
                        if not orderpoint:
                            location = record.company_id.location_id
                            orderpoint = self.env["stock.warehouse.orderpoint"].search(
                                [
                                    ("product_id", "=", product.id),
                                    ("location_id", "=", location.id),
                                ], limit=1
                            )
                        min_quantity = orderpoint.product_min_qty
                        max_quantity = orderpoint.product_max_qty

                        if not min_quantity < 0 and not max_quantity < 0:
                            if on_hand < min_quantity:
                                validation_texts.append(
                                    "- "
                                    + product.display_name
                                    + " is below its minimum level."
                                )
                            if on_hand > max_quantity:
                                validation_texts.append(
                                    "- "
                                    + product.display_name
                                    + " is above its maximum level."
                                )

            if len(validation_texts) > 0:
                record.validation_text = ""
                for validation_text in validation_texts:
                    record.validation_text = (
                        record.validation_text + validation_text + "\n"
                    )

                validation_form = self.env.ref(
                    "workshop.delivery_order_return_popup_form"
                )
                popup = {
                    "name": _("Confirmation"),
                    "type": "ir.actions.act_window",
                    "view_mode": "form",
                    "view_id": validation_form.id,
                    "res_model": "stock.return.picking",
                    "res_id": self.id,
                    "target": "new",
                }
                return popup
            else:
                return self.create_returns()

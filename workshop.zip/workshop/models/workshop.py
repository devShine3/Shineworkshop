import logging
from datetime import date
from datetime import datetime
from enum import Enum
from dateutil.relativedelta import relativedelta
from psutil import long

from odoo.exceptions import UserError
from odoo import http, models, api, fields, _
from .car_record import RecordData

_logger = logging.getLogger(__name__)

class ReceivedTypes(Enum):
    RECEIPTS = ("incoming", "Receipt")
    TRANSFER = ("internal", "Internal Tranfer")

    val = lambda x: x.value[0]
    label = lambda x: x.value[1]
    selection = lambda x: (x.value[0], x.value[1])

    @classmethod
    def get_selection_received_type(cls):
        _selection = []
        for received_type in cls:
            _selection.append(received_type.selection())
        return _selection


class CarWorkshop(models.Model):
    _name = "car.workshop"
    _description = "Car Workshop"
    _inherit = ["portal.mixin", "mail.thread", "mail.activity.mixin"]

    def _get_default_vehicle(self):
        car_id = self._context.get("active_id")
        car = self.env["fleet.vehicle"].browse(car_id)
        if car.name:
            return car.name.id
        else:
            return 1

    vehicle_id = fields.Many2one(
        "fleet.vehicle",
        string="Vehicle",
        index=True,
        tracking=True,
        change_default=True,
    )
    today_delivered_date = fields.Date()
    # vehicle_state = fields.Integer(related="vehicle_id.state_id.id")

    @api.model
    def _default_company_id(self):
        car_id = self._context.get("active_id")
        car = self.env["fleet.vehicle"].browse(car_id)
        if car:
            return car.company_id.id
        else:
            return self.env.company

    def _get_default_partner(self):
        if "default_partner_id" in self.env.context:
            default_partner_id = self.env["fleet.vehicle"].browse(
                self.env.context["default_partner_id"]
            )
            return default_partner_id.partner_id

    def _get_default_stage_id(self):
        """Gives default stage_id"""
        vehicle_id = self.env.context.get("default_vehicle_id")
        if not vehicle_id:
            return False
        stage = self.stage_find(vehicle_id, [("stage_id.name", "=", "done")])
        return stage

    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        return self.env["worksheet.stages"].search([], order=order)

    name = fields.Char(string="Title", track_visibility="onchange", required=True)
    user_id = fields.Many2one(
        "res.users",
        string="Assigned to",
        default=lambda self: self.env.user,
        tracking=True,
    )
    active = fields.Boolean(string="Active", default=True)
    partner_id = fields.Many2one(
        "res.partner", string="Customer", default=_get_default_partner
    )
    priority = fields.Selection(
        [("0", "Normal"), ("1", "High")], "Priority", select=True, default="0"
    )
    description = fields.Html(string="Description")
    sequence = fields.Integer(
        string="Sequence",
        select=True,
        default=10,
        help="Gives the sequence order when displaying a list of tasks.",
    )
    tag_ids = fields.Many2many("workshop.tag", string="Tags", ondelete="cascade")
    kanban_state = fields.Selection(
        [
            ("normal", "In Progress"),
            ("done", "Ready for next stage"),
            ("blocked", "Blocked"),
        ],
        "Kanban State",
        help="A task's kanban state indicates special situations affecting it:\n"
        " * Normal is the default situation\n"
        " * Blocked indicates something is preventing the progress of this task\n"
        " * Ready for next stage indicates the task is ready to be pulled to the next stage",
        required=True,
        track_visibility="onchange",
        default="normal",
        copy=False,
    )
    create_date = fields.Datetime(string="Create Date", readonly=True, select=True)
    write_date = fields.Datetime(
        string="Last Modification Date", readonly=True, select=True
    )
    date_start = fields.Datetime(
        string="Starting Date", default=fields.datetime.now(), select=True, copy=False
    )
    date_end = fields.Datetime(string="Ending Date", select=True, copy=False)
    date_assign = fields.Datetime(string="Assigning Date", select=True, copy=False)
    date_deadline = fields.Datetime(string="Deadline", select=True, copy=False)
    progress = fields.Integer(
        string="Working Time Progress(%)", copy=False, readonly=True
    )
    date_last_stage_update = fields.Datetime(
        string="Last Stage Update",
        select=True,
        default=fields.datetime.now(),
        copy=False,
        readonly=True,
    )
    id = fields.Integer("ID", readonly=True)
    company_id = fields.Many2one(
        "res.company", string="Company", required=True, default=_default_company_id
    )

    color = fields.Integer(string="Color Index")
    stage_id = fields.Many2one(
        "worksheet.stages",
        string="Stage",
        default=lambda self: self._get_default_stage(),
        group_expand="_read_group_stage_ids",
        tracking=True,
    )

    state = fields.Selection(
        [
            ("waiting", "Ready"),
            ("workshop_create_invoices", "Invoiced"),
            ("cancel", "Invoice Canceled"),
        ],
        string="Status",
        default="waiting",
        select=True,
        readonly=False,
    )
    attachment_ids = fields.One2many(
        "ir.attachment",
        "res_id",
        domain=lambda self: [("res_model", "=", self._name)],
        auto_join=True,
        string="Attachments",
    )
    displayed_image_id = fields.Many2one(
        "ir.attachment",
        domain="["
        "('res_model', '=', 'car.workshop'),"
        "('res_id', '=', id),"
        "('mimetype', 'ilike', 'image')]",
        string="Displayed Image",
    )
    planned_works = fields.One2many(
        "planned.work", "work_id", string="Planned/Ordered Works"
    )
    works_done = fields.One2many(
        "planned.work", "work_id", string="Work Done", domain=[("completed", "=", True)]
    )
    materials_used = fields.One2many(
        "material.used", "material_id", string="Materials Used"
    )  # default=lambda self: [(0, 0, {'amount': 1})]
    remaining_hour = fields.Float(
        string="Remaining Hour", readonly=True, compute="hours_left"
    )
    effective_hour = fields.Float(
        string="Hours Spent", readonly=True, compute="hours_spent"
    )
    amount_total = fields.Float(
        string="Total Amount", readonly=True, compute="amount_total1"
    )
    invoice_count = fields.Integer(
        string="Invoice_count", compute="compute_invoice_count"
    )
    so_count = fields.Integer(string="Sale Order Count", compute="compute_so_count")
    invoice_include = fields.Selection(
        [
            ("service", "Service"),
            ("product_use", "Material Used"),
            ("both", "All"),
        ],
        string="Invoice Type",
        default="both",
        select=True,
        required="1",
    )
    car_delivered = fields.Boolean(string="Car Delivered", default=False)
    comeback_job = fields.Boolean(string="Comeback Job", default=False)
    done_stage = fields.Boolean(
        compute="compute_worksheet_stage",
        default=False,
        store=True,
        depends=["stage_id"],
    )

    def compute_worksheet_stage(self):
        for record in self:
            stage = record.env["worksheet.stages"].search(
                [("name", "=", "DONE")], limit=1
            )
            record.done_stage = record.stage_id == stage

    sale_order_ids = fields.Many2many("sale.order", string="Sale Orders")
    picking_ids = fields.Many2many(
        comodel_name="stock.picking",
        string="Transfers",
        # domain="[('picking_type_id.code', '=', received_type), ('is_used', '=', False), ('is_received', '=', True), ('vehicle_id', '=', vehicle_id)]",
        domain="[('is_used', '=', False), ('is_received', '=', True), ('vehicle_id', '=', vehicle_id), '|', ('picking_type_id.code', '=', 'incoming'), ('picking_type_id.code', '=', 'internal')]"
    )

    def _get_source_location(self, po_name):
        return (
            self.env["stock.picking"]
            .search([("origin", "=", po_name)])
            .location_dest_id.id
        )

    def _get_po_price(self, purchase_id, product_id):
        po_id = self.env["purchase.order"].browse(purchase_id)
        for line in po_id.order_line:
            if line.product_id.id == product_id:
                return line.price_unit
        return None

    @api.onchange("received_type")
    def _onchange_received_type(self):
        self.picking_ids = False
        self.materials_used = [(5, 0, 0)]

    @api.onchange("picking_ids")
    def _onchange_picking_ids(self):
        # Clearing existing records in materials_used
        # import pdb; pdb.set_trace()
        self.materials_used = [(2, rec.id, 0) for rec in self.materials_used]

        if self.picking_ids:
            material_used_lines = []

            for picking in self.picking_ids:
                for line in picking.move_ids_without_package:
                    material_used_line_values = {
                        "material": line.product_id.id,
                        "amount": line.quantity_done,
                        "location_src_id": picking.location_dest_id.id,
                        "price": self._get_po_price(
                            picking.purchase_id.id, line.product_id.id
                        ),
                        "invoice_select": True,
                    }
                    material_used_lines.append((0, 0, material_used_line_values))

            # Adding new or updated records to materials_used
            self.materials_used = material_used_lines

    @api.depends("planned_works.work_cost", "materials_used.price")
    def amount_total1(self):
        for records in self:
            for hour in records:
                amount_totall = 0.0
                for line in hour.planned_works:
                    amount_totall += line.work_cost
                for line2 in hour.materials_used:
                    amount_totall += line2.price * line2.amount
                records.amount_total = amount_totall

    def cancel(self):
        self.state = "cancel"


    def workshop_create_invoices(self):
        self.state = "workshop_create_invoices"
        inv_obj = self.env["account.move"]
        inv_line_obj = self.env["account.move.line"]
        customer = self.partner_id
        if not customer.name:
            raise UserError(_("Please select a Customer."))

        invoice_line_ids = []
        company_id = self.env["res.users"].browse(1).company_id
        currency_value = company_id.currency_id.id
        self.ensure_one()
        journal_id = (
            self.env["ir.config_parameter"]
            .sudo()
            .get_param("workshop.invoice_journal_type")
        )
        if not journal_id:
            journal_id = 1

        inv_data = {
            "ref": self.id,
            "partner_bank_id": customer.bank_ids[:1].id,
            "partner_id": customer.id,
            "currency_id": currency_value,
            "journal_id": int(journal_id),
            "invoice_origin": self.name,
            "company_id": company_id.id,
            "move_type": "out_invoice",
        }

        # if self.invoice_include != 'product_use':
        posted_invoices = inv_obj.search([
            "|",
            ("vehicle_id", "=", self.vehicle_id.id),
            ("sale_order_id.workshop_ids.id", "=", self.id),
            ('state','=','posted'),
            ('move_type','=','out_invoice')
        ])

        material_exists = False
        work_exists = False

        if self.planned_works:
            for plan_record in self.planned_works:
                if plan_record.invoice_select:
                    if not plan_record.invoice_done:
                        if plan_record.completed:
                            if plan_record.planned_work:
                                income_account = False
                                if plan_record.planned_work.property_account_income_id:
                                    income_account = (
                                        plan_record.planned_work.property_account_income_id.id
                                    )
                                else:
                                    income_account = (
                                        plan_record.planned_work.categ_id.property_account_income_categ_id.id
                                    )
                                
                                plan_is_posted = False
                                for posted_invoice in posted_invoices:
                                    for line in posted_invoice.invoice_line_ids:
                                        posted_product = line.product_id
                                        if plan_record.planned_work.id == posted_product.id:
                                            plan_is_posted = True
                                            break
                                if plan_is_posted == False:
                                    inv_line_data = (
                                        0,
                                        0,
                                        {
                                            "name": plan_record.planned_work.name,
                                            "account_id": income_account,
                                            "price_unit": plan_record.work_cost,
                                            "quantity": 1,
                                            "product_id": plan_record.planned_work.id,
                                        },
                                    )
                                    invoice_line_ids.append(inv_line_data)

                            if not income_account:
                                raise UserError(
                                    _(
                                        'There is no income account defined for this product: "%s".'
                                    )
                                    % (plan_record.planned_work.name,)
                                )
        
        if self.materials_used:
            for material_record in self.materials_used:
                if material_record.invoice_select:
                    if not material_record.invoice_done:
                        if material_record.material:
                            income_account = False
                            if material_record.material.property_account_income_id:
                                income_account = (
                                    material_record.material.property_account_income_id.id
                                )
                            else:
                                income_account = (
                                    material_record.material.categ_id.property_account_income_categ_id.id
                                )

                            material_is_posted = False
                            for posted_invoice in posted_invoices:
                                for line in posted_invoice.invoice_line_ids:
                                    posted_product = line.product_id
                                    if material_record.material.id == posted_product.id:
                                        material_is_posted = True
                                        if material_record.picking_id and material_record.picking_id.is_used == False:
                                            material_record.picking_id.is_used = True
                                        break
                            if material_is_posted == False:
                                inv_line_data = (
                                    0,
                                    0,
                                    {
                                        "name": material_record.material.display_name,
                                        "account_id": material_record.material.property_account_income_id.id,
                                        "price_unit": material_record.price,
                                        "quantity": material_record.amount,
                                        "product_id": material_record.material.id,
                                        "material_used_id": material_record.id,
                                        "picking_id": material_record.picking_id.id,
                                    },
                                )
                                invoice_line_ids.append(inv_line_data)
                        
                        if not income_account:
                            raise UserError(
                                _(
                                    'There is no income account defined for this product: "%s".'
                                )
                                % (material_record.material.name,)
                            )

        inv_data.update({"invoice_line_ids": invoice_line_ids})
        if self.vehicle_id:
            inv_data.update({"vehicle_id": self.vehicle_id})

        inv_id = inv_obj.create(inv_data)
        # if self.picking_ids:  # Assuming picking_ids is the new Many2Many field
        #     inv_id.sudo().write({"picking_ids": [(6, 0, self.picking_ids.ids)]})
        if self.picking_id:
            inv_id.sudo().write({"picking_id": self.picking_id.id})

        inv_id._onchange_partner_id()

        # on change partner_ID
        result = {
            "type": "ir.actions.act_window",
            "name": _("Invoice"),
            "view_mode": "form",
            "res_model": "account.move",
            "target": "current",
            "res_id": inv_id.id,
        }

        IMD = self.env["ir.model.data"]
        form_view_id = IMD._xmlid_to_res_id("account.invoice_form")
        if len(inv_id) > 1:
            result["domain"] = "[('id','in',%s)]" % inv_id.ids
        elif len(inv_id) == 1:
            result["views"] = [(form_view_id, "form")]
            result["res_id"] = inv_id.ids[0]
        else:
            result = {"type": "ir.actions.act_window_close"}
        invoiced_records = self.env["car.workshop"]

        total = 0
        for rows in invoiced_records:
            invoiced_date = rows.date
            invoiced_date = invoiced_date[0:10]
            if invoiced_date == str(date.today()):
                total = total + rows.price_subtotal
        
        return result

    @api.depends("works_done.duration")
    def hours_spent(self):
        for hour in self:
            effective_hour = 0.0
            for line in hour.works_done:
                effective_hour += line.duration
            self.effective_hour = effective_hour

    @api.depends("planned_works.time_spent")
    def hours_left(self):
        for hour in self:
            remaining_hour = 0.0
            for line in hour.planned_works:
                remaining_hour += line.time_spent
            self.remaining_hour = remaining_hour - self.effective_hour

    def process_demo_scheduler_queue(self):
        obj = self.env["car.workshop"]
        obj1 = obj.search([])
        now = fields.Datetime.from_string(fields.Datetime.now())
        for obj2 in obj1:
            obj3 = obj2
            if (
                obj3.stage_id.name != "Done"
                and obj3.stage_id.name != "Cancelled"
                and obj3.stage_id.name != "Verified"
            ):
                end_date = fields.Datetime.from_string(obj3.date_deadline)
                start_date = fields.Datetime.from_string(obj3.date_assign)
                if obj3.date_deadline and obj3.date_assign and end_date > start_date:
                    if now < end_date:
                        diff1 = relativedelta(end_date, start_date)
                        if diff1.days == 0:
                            total_hr = int(diff1.minutes)
                        else:
                            total_hr = int(diff1.days) * 24 * 60 + int(diff1.minutes)
                        diff2 = relativedelta(now, start_date)
                        if diff2.days == 0:
                            current_hr = int(diff2.minutes)
                        else:
                            current_hr = int(diff2.days) * 24 * 60 + int(diff2.minutes)

                        if total_hr != 0:
                            obj3.progress = (current_hr * 100) / total_hr
                        else:
                            obj3.progress = 100
                    else:
                        obj3.progress = 100
                else:
                    obj3.progress = 0

    @api.model
    def _track_subtype(self, init_values):
        record = self.ensure_one()
        if "kanban_state" in init_values and record.kanban_state == "blocked":
            return self.env.ref("workshop.mt_task_blocked")
        elif "kanban_state" in init_values and record.kanban_state == "done":
            return self.env.ref("workshop.mt_task_ready")
        elif "user_id" in init_values and record.user_id:  # assigned -> new
            return self.env.ref("workshop.mt_task_new")
        elif (
            "stage_id" in init_values
            and record.stage_id
            and record.stage_id.sequence <= 1
        ):  # start stage -> new
            self.env.ref("workshop.mt_task_new")
        elif "stage_id" in init_values:
            return self.env.ref("workshop.mt_task_stages")
        return super(CarWorkshop, self)._track_subtype(init_values)

    @api.model
    def create(self, vals):
        _logger.info(f"Create method executed with vals: {vals}")
        # context: no_log, because subtype already handle this
        context = dict(self.env.context, mail_create_nolog=True)
        # for default stage
        if vals.get("vehicle_id") and not context.get("default_vehicle_id"):
            context["default_vehicle_id"] = vals.get("vehicle_id")

        # user_id change: update date_assign
        if vals.get("user_id"):
            vals["date_assign"] = fields.Datetime.now()

        # Stage change: Update date_end if folded stage and date_last_stage_update
        if vals.get("stage_id"):
            vals.update(self.change_date_end(vals["stage_id"]))
            vals["date_last_stage_update"] = fields.Datetime.now()

        task = super(CarWorkshop, self.with_context(context)).create(vals)
        self.create_record(
            RecordData(
                worksheet_id=task.id,
                stage_id=vals.get("stage_id"),
                vehicle_id=task.vehicle_id.id,
                state_id=task.vehicle_id.state_id.id,
            )
        )

        return task

    def _get_finishing_state(self):
        return (
            self.env["worksheet.stages"]
            .search([("finishing_state", "=", True)], limit=1, order="create_date desc")
            .id
        )

    def create_record(self, data: RecordData) -> None:
        self.env["car.record"].sudo().create(data.__dict__)

    # def create_delivery_record(self, worksheet_id: int, stage_id: int, vehicle_id: int) -> None:
    #     return self.env['car.deliver.check'].create({'worksheet_id': worksheet_id, 'stage_id': stage_id, 'vehicle_id': vehicle_id})
    #     return result
    def write(self, vals):
        now = fields.Datetime.now(self)
        if "stage_id" in vals:
            vals.update(self.change_date_end(vals["stage_id"]))
            vals["date_last_stage_update"] = now
            # reset kanban state when changing stage
            if "kanban_state" not in vals:
                vals["kanban_state"] = "normal"
            if vals.get("stage_id") == self._get_finishing_state():
                self.create_record(
                    RecordData(
                        worksheet_id=self.id,
                        stage_id=vals.get("stage_id"),
                        vehicle_id=self.vehicle_id.id,
                        state_id=self.vehicle_id.state_id.id,
                    )
                )
        # user_id change: update date_assign
        if vals.get("user_id") and "date_assign" not in vals:
            vals["date_assign"] = now
        # old_stage_id = self.stage_id.id
        return super(CarWorkshop, self).write(vals)
        return result

    def change_date_end(self, stage_id):
        worksheet_stage = self.env["worksheet.stages"].browse(stage_id)
        if worksheet_stage.fold:
            return {"date_end": fields.Datetime.now()}
        return {"date_end": False}

    @api.onchange("vehicle_id")
    def onchange_vehicle(self):
        if self.vehicle_id.exists():
            self.partner_id = self.vehicle_id.partner_id
            
            # self.stage_id = self.stage_find(self.vehicle_id, [('fold', '=', False)])
            # vehicle_state_filter = [
            #     ('finishing_state', '=', 'True')
            # ]
            # vehicle_state_record = http.request.env['fleet.vehicle.state'].search(vehicle_state_filter)
            # if vehicle_state_record:
            #     self.today_delivered_date = datetime.today()
            #     self.vehicle_id.state_id = vehicle_state_record
            #     if self.today_delivered_date:
            #         for record in self:
            #             record.car_delivered = False

            inv_obj = self.env["account.move"]
            posted_invoices = inv_obj.search([
                # "|",
                ("vehicle_id", "=", self.vehicle_id.id),
                # ("sale_order_id.workshop_ids.id", "=", self.id),
                ('state','=','posted'),
                ('move_type','=','out_invoice')
            ])
            transfers = self.env["stock.picking"].search([
                ('is_used', '=', False), ('is_received', '=', True), ('vehicle_id', '=', self.vehicle_id.id), '|', ('picking_type_id.code', '=', 'incoming'), ('picking_type_id.code', '=', 'internal')
            ])
            for posted_invoice in posted_invoices:
                for posted_line in posted_invoice.invoice_line_ids:
                    for transfer in transfers:
                        for transfer_line in transfer.move_line_ids_without_package:
                            if posted_line.product_id == transfer_line.product_id:
                                if transfer.is_received == True and transfer.is_used == False:
                                    transfer.is_used = True

    @api.onchange("materials_used")
    def _onchange_materials_used(self):
        for line in self.materials_used:
            if not line.amount:
                line.amount = 1
            # for picking in self.picking_ids:
            #     for line in picking.move_ids_without_package:

    def stage_find(self, section_id, domain=[], order="sequence"):
        """Override of the base.stage method
        Parameter of the stage search taken from the lead:
        - section_id: if set, stages must belong to this section or
          be a default stage; if not set, stages must be default
          stages
        """
        # collect all section_ids
        section_ids = []
        if section_id:
            section_ids.append(section_id)
        section_ids.extend(self.mapped("vehicle_id").ids)
        search_domain = []
        if section_ids:
            search_domain = [("|")] * (len(section_ids) - 1)
            for section_id in section_ids:
                if isinstance(section_id, (int, long)):
                    search_domain.append(("vehicle_ids", "=", section_id))
        search_domain += list(domain)
        # perform search, return the first found
        stage_ids = (
            self.env["worksheet.stages"].search(search_domain, order=order, limit=1).id
        )
        if stage_ids:
            return stage_ids
        return False

    def get_invoices(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Invoices",
            "view_mode": "tree,form",
            "view_type": "form",
            "res_model": "account.move",
            "domain": [("invoice_origin", "=", self.name)],
            "context": "{'create': False}",
        }

    def get_so(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Sale Orders",
            "view_mode": "tree,form",
            "view_type": "form",
            "res_model": "sale.order",
            "domain": [("workshop_ids", "=", self.id)],
            "context": "{'create': False}",
        }

    def compute_invoice_count(self):
        for record in self:
            record.invoice_count = self.env["account.move"].search_count(
                [("invoice_origin", "=", self.name)]
            )

    def compute_so_count(self):
        for record in self:
            record.so_count = self.env["sale.order"].search_count(
                [("workshop_ids", "=", self.id)]
            )

    def _get_default_stage(self):
        stage = self.env.ref(
            "workshop.worksheet_stage_registered", raise_if_not_found=False
        )
        return stage if stage and stage.id else False
from odoo import models, fields


class CarCheck(models.Model):
    _name = "workshop.car_check"
    _description = "Workshop Car Check"

    name = fields.Char(string="Name")
    exists = fields.Boolean(string="Exists")
    working = fields.Boolean(string="Working")
    remark = fields.Char(string="Remark")

    checklist = fields.Many2one("workshop.checklist", string="Checklist")
    check_items = fields.Many2one("workshop.check_setup", string="Items")

    flag = fields.Boolean(compute="check_group")
    state = fields.Selection(
        [
            ("draft", "To Confirm"),
            ("confirmed", "Confirmed"),
        ],
        string="Status",
        default="draft",
        required=True,
    )

    def check_group(self):
        for rec in self:
            if self.user_has_groups("workshop.access_workshop_checklist_group"):
                rec.flag = True
            else:
                rec.flag = False

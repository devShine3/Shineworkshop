# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import account
from . import car_register
from . import checklist
from . import customer
from . import lubricant
from . import resconfig
from . import signature
from . import workshop_car_check
from . import workshop_check_setup
from . import workshop_checklist
from . import workshop_inventory
from . import workshop_tag
from . import workshop
from . import sale_order
from . import contract
from . import fleet_vehicle_state

from . import purchase
from . import customer_tag

# from . import purchase
from . import stock_picking
from . import comeback_state

# from . import company
from . import inventory
from . import car_record

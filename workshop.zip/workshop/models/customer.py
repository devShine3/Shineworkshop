from odoo import models, fields


class FleetContract(models.Model):
    _inherit = "fleet.vehicle.log.contract"

    insurer_id = fields.Many2one("res.partner", "Customer")


class FleetService(models.Model):
    _inherit = "fleet.vehicle.log.services"

    vendor_id = fields.Many2one("res.partner", "Customer")

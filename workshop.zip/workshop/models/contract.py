from odoo import models, fields


class FleetContract(models.Model):
    _inherit = "fleet.vehicle.log.contract"

    vehicle_id = fields.Many2one(
        "fleet.vehicle",
        "Vehicle",
        required=False,
        help="Vehicle concerned by this log",
        check_company=True,
    )

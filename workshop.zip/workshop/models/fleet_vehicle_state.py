from odoo import models, fields


class VehicleStatus(models.Model):
    _inherit = "fleet.vehicle.state"

    finishing_state = fields.Boolean(string="Finishing State", default=False)
    comeback_job = fields.Boolean(string="Comeback Job State", default=False)

from odoo import models, fields

class ComebackStatus(models.Model):
    _name = "comeback.job"
    _inherit = "fleet.vehicle.state"

    name = fields.Integer(string="Comeback")
    comeback_job = fields.Boolean(string="Comeback Job State", default=False)
    vehicle_id = fields.Many2one("fleet.vehicle", string="Vehicle")
    partner_id = fields.Many2one("res.partner", string="Customer")

# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, Command, models, fields, http, _
from odoo.exceptions import ValidationError


class FleetVehicle(models.Model):
    _inherit = "fleet.vehicle"

    license_plate = fields.Char(
        tracking=True,
        help="License plate number of the vehicle (i = plate number for a car)",
        unique=True,
    )

    _sql_constraints = [
        (
            "license_plate_unique",
            "unique (license_plate)",
            "License plate already exists !",
        )
    ]

    customer_tags = fields.Many2many(
        "res.partner.category", related="partner_id.category_id", string="Customer Tags"
    )

    def _get_default_state(self):
        state = self.env.ref(
            "fleet.fleet_vehicle_state_new_request", raise_if_not_found=False
        )
        return state if state and state.id else False

    def _default_check_list(self):
        array = []
        check_name = self.env["fleet.service.type"].search(
            [("category", "=", "service")]
        )
        for name in check_name:
            check_list = (
                0,
                None,
                {
                    "name": name.name,
                    "part_yes": False,
                    "part_no": False,
                    "condition_good": False,
                    "condition_bad": False,
                },
            )
            array.append(check_list)
        return array

    check_id = fields.One2many(
        "checklist",
        "car_id",
        string="Check Lists For Workshop",
        default=_default_check_list,
    )
    worksheet = fields.One2many("car.workshop", "vehicle_id", string="Task Activities")
    partner_id = fields.Many2one(
        "res.partner", "Customer", tracking=True, help="Workshop Customers", copy=False
    )
    type_ids = fields.Many2many(
        "worksheet.stages",
        "car_workshop_type_rel",
        "vehicle_id",
        "type_id",
        string="Worksheet Stages",
        states={"close": [("readonly", True)], "cancelled": [("readonly", True)]},
    )
    use_tasks = fields.Boolean(string="Register for Workshop", default=False)
    task_count = fields.Integer(
        compute="_compute_task_count", type="integer", string="Tasks"
    )
    doc_count = fields.Integer(
        compute="_compute_attached_docs_count", string="Number of documents attached"
    )
    task_ids = fields.One2many(
        "car.workshop",
        "vehicle_id",
        domain=["|", ("stage_id.fold", "=", False), ("stage_id", "=", False)],
    )
    label_tasks = fields.Char(
        string="Use Tasks as",
        help="Gives label to Work on kanban view.",
        default="Task",
    )

    state_id = fields.Many2one(
        "fleet.vehicle.state",
        "State",
        default=_get_default_state,
        group_expand="_read_group_stage_ids",
        tracking=True,
        help="Current state of the vehicle",
        ondelete="set null",
    )
    contract_customer = fields.Char(
        string="Contract Customer", compute="_compute_cus_name"
    )
    create_date = fields.Datetime(string="Create Date", readonly=True, select=True)

    def _compute_cus_name(self):
        for record in self:
            log_contract = self.env["fleet.vehicle.log.contract"].search(
                [("vehicle_id", "=", record.id)], order="id desc", limit=1
            )
            record.contract_customer = log_contract.insurer_id.name

    def _compute_task_count(self):
        for vehicle in self:
            not_done_tasks = vehicle.task_ids.filtered(
                lambda task: task.stage_id.name != 'DONE'
            )
            vehicle.task_count = len(not_done_tasks)

    # def _compute_task_count(self):
    #     for vehicle in self:
    #         vehicle.task_count = len(vehicle.task_ids)

    def _compute_attached_docs_count(self):
        Attachment = self.env["ir.attachment"]
        for vehicle in self:
            vehicle.doc_count = Attachment.search_count(
                [
                    "|",
                    "&",
                    ("res_model", "=", "fleet.vehicle"),
                    ("res_id", "=", vehicle.id),
                    "&",
                    ("res_model", "=", ".worksheet"),
                    ("res_id", "in", vehicle.task_ids.ids),
                ]
            )

    def attachment_tree_views(self):
        self.ensure_one()
        domain = [
            "|",
            "&",
            ("res_model", "=", "fleet.vehicle"),
            ("res_id", "in", self.ids),
            "&",
            ("res_model", "=", "car.workshop"),
            ("res_id", "in", self.task_ids.ids),
        ]

        return {
            "name": _("Attachments"),
            "domain": domain,
            "res_model": "ir.attachment",
            "type": "ir.actions.act_window",
            "view_id": False,
            "view_mode": "kanban,tree,form",
            "view_type": "form",
            "help": _(
                """<p class="oe_view_nocontent_create">
                        Documents are attached to the tasks and issues of your Worksheet.</p><p>
                        Send messages or log internal notes with attachments to link
                        documents to your Worksheet.
                    </p>"""
            ),
            "limit": 80,
            "context": "{'default_res_model': '%s','default_res_id': %d}"
            % (self._name, self.id),
        }

    # @api.onchange('state_id')
    # def _onchange_state_id(self):
    #     worksheet_stage_filter = [
    #         # ('name', '=', 'Done')
    #         ('finishing_state', '=', True)
    #     ]
    #     worksheet_stage_record = http.request.env['worksheet.stages'].search(worksheet_stage_filter)

    #     vehicle_state_filter = [
    #         # ('name', '=', 'Delivered')
    #         ('finishing_state', '=', True)
    #     ]
    #     vehicle_state_record = http.request.env['fleet.vehicle.state'].search(vehicle_state_filter)

    #     worksheet_filter = [
    #         ('vehicle_id', '=', self.id.origin),
    #         ('stage_id', '=', worksheet_stage_record['id']),
    #         ('car_delivered', '=', False)
    #     ]
    # worksheet_record = http.request.env['car.workshop'].search(worksheet_filter)

    # for worksheet in worksheet_record:
    #     if worksheet['stage_id']['id'] == worksheet_stage_record['id'] and self['state_id']['id'] == vehicle_state_record['id']:
    #         worksheet['car_delivered'] = True
    # return

    def write(self, vals):
        # import pdb; pdb.set_trace()
        # old_state_id = self.state_id.id
        result = super(FleetVehicle, self).write(vals)
        # if self.state_id.id == self._get_finishing_state() or old_state_id == self._get_finishing_state():
        #     self.create_delivery_record(vehicle_id=self.id, state_id=self.state_id.id)
        print("Write method executed with vals:", vals)

        if vals.get("state_id"):
            comeback_states = self.env["fleet.vehicle.state"].search(
                [("comeback_job", "=", True)], limit=1
            )
            if comeback_states.id == vals.get("state_id"):
                for comeback_state in comeback_states:
                    print(
                        "Creating record in comeback.job model for comeback state:",
                        comeback_state,
                    )
                    comeback_status_vals = {
                        "vehicle_id": self.id,
                        "partner_id": self.partner_id.id,
                        "comeback_job": True,
                    }
                    new_record = self.env["comeback.job"].create(comeback_status_vals)
                    print("New record created in comeback.job model:", new_record)
        else:
            print("Conditions not met for creating a record in comeback.job model")
        return result

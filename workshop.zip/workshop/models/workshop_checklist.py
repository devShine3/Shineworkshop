from odoo import api, models, fields
from datetime import date, datetime, timedelta

check_items = [
    "Lights - Left/Right",
    "Side Lamps - Front/Back",
    "Signal Lights - Left/Right",
    "Fog Lamp",
    "Rear Lamps",
    "Back Camera",
    "Censors - Front/Back",
    "Number Plate Lamp",
    "Brake Lamps",
    "Spare Wheel",
]


class CarChecklist(models.Model):
    _name = "workshop.checklist"
    _description = "Car Checklist"
    _inherit = ["portal.mixin"]

    car_id = fields.Many2one("fleet.vehicle", string="Vehicle")
    date_time = fields.Datetime(
        string="Date/Time", required=True, default=lambda self: self._today_date()
    )
    notes = fields.Text(string="Notes")
    car_check = fields.One2many(
        "workshop.car_check",
        "checklist",
        string="Data",
        default=lambda self: self._default_car_check(),
    )
    sign = fields.Binary(string="Service Advisor's Sign")
    owner_sign = fields.Binary(string="Owner's Sign")

    date = fields.Date(string="Date", compute="_compute_date_field", store=True)
    flag = fields.Boolean(compute="check_group")

    state = fields.Selection(
        [
            ("to_confirm", "Save"),
            ("confirmed", "Confirmed"),
        ],
        string="Status",
        default="to_confirm",
        required=True,
    )
    # state_and_user = fields.Boolean(compute='user_group')

    def confirmed_checklist(self):
        for rec in self:
            rec.state = "confirmed"

    # def user_group(self):
    #     for rec in self:
    #         if self.user_has_groups('base.group_erp_manager'):
    #             rec.state_and_user = True
    #         else:
    #             rec.state_and_user = False

    def check_group(self):
        for rec in self:
            if self.user_has_groups("workshop.access_workshop_checklist_group"):
                rec.flag = True
            else:
                rec.flag = False

    @api.depends("date_time")
    def _compute_date_field(self):
        for record in self:
            if record.date_time:
                record.date = record.date_time.date()
            else:
                record.date = False

    def name_get(self):
        result = []
        format_date = ""
        for record in self:
            # Modify this logic to generate the desired label
            if record.date_time:
                format_date = record.date_time + timedelta(hours=6, minutes=30, days=0)
                format_date = format_date.strftime("%d-%m-%Y %H:%M")
            else:
                format_date = record.create_date.strftime("%d-%m-%Y %H:%M")
            display_name = "%s" % (format_date)
            result.append((record.id, display_name))
        return result

    @api.model
    def _default_car_check(self):
        default_car_check = []
        check_items = self.env["workshop.check_setup"].search([])

        for item in check_items:
            default_car_check.append(
                (
                    0,
                    0,
                    {
                        "name": item.name,
                        "exists": False,
                        "working": False,
                        "remark": "",
                    },
                )
            )

        return default_car_check

    def preview_checklist(self):
        # url = '/my/checklist_preview?record_id=' + str(self.id)
        # return {
        #     'type': 'ir.actions.act_url',
        #     'url': url,
        #     'target': 'self'
        #     # 'target': 'new',
        # }

        self.ensure_one()
        return {
            "type": "ir.actions.act_url",
            "target": "",
            "url": self.get_portal_url(),
        }

    def _compute_access_url(self):
        super(CarChecklist, self)._compute_access_url()
        for checklist in self.filtered(lambda checklist: checklist.is_checklist()):
            checklist.access_url = "/my/checklists/%s" % (checklist.id)

    def is_checklist(self):
        correct_checklist = False
        if self:
            correct_checklist = True
        return correct_checklist

    def _today_date(self):
        current_date = datetime.now()
        new_date = current_date  # + timedelta(hours=6,  minutes=30, days=0)
        return new_date

    def download_report(self):
        data = {}
        data["form"] = {
            "id": 275,
            "car_id": (7, "Toyota/Belta/5G-2060"),
            "car_checklist": (60, "16-08-2023 10:30"),
            "date_from": False,
            "date_to": False,
            "report_date": "16-08-2023 10:30",
        }
        report_wizard = self.env["checklist.report.wizard"]
        report_wizard.custom_print(data)

    def _get_report_base_filename(self):
        return self.display_name

    # @api.model
    # def default_get(self, fields_list):
    #     defaults = super(CarChecklist, self).default_get(fields_list)
    #     # Create 8 default child records
    #     child_defaults = [
    #         {
    #             'name': f'Child {i + 1}',
    #             'exists': True,
    #             'working': False,
    #             'remark': f'Remark {i + 1}'
    #         }
    #         for i in range(8)
    #     ]
    #     defaults['car_check'] = [(0, 0, child_data) for child_data in child_defaults]
    #     return defaults

    # @api.model
    # @api.onchange('car_id')
    # def _onChange(self):
    #     self.car_check = [(0, 0, {
    #         'name': f'Child {i + 1}',
    #         'exists': True,
    #         'working': False,
    #         'remark': f'Remark {i + 1}'
    #     }) for i in range(8)]

    # @api.onchange('car_id')
    # def _onChange(self):
    #     # Load existing records from workshop.car_check into the car_check field
    #     filter = [
    #         ('name', '=', 'Lights - Left/Right'),
    #         ('exists', '=', False),
    #         ('working', '=', False),
    #         ('remark', '=', '')
    #     ]
    #     original_check_records = self.env['workshop.car_check'].search(filter)

    #     check_records = [
    #         (0, 0, {
    #             'name': check.name,
    #             'exists': check.exists,
    #             'working': check.working,
    #             'remark': check.remark,
    #         }) for check in original_check_records
    #     ]

    #     self.car_check = original_check_records

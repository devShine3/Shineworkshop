from odoo import models, fields


class CarCheckSetup(models.Model):
    _name = "workshop.check_setup"

    name = fields.Char(string="Name")

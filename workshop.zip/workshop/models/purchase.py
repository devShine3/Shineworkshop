from odoo import models, fields, api


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    is_used = fields.Boolean(default=False)
    is_received = fields.Boolean(
        default=False, compute="_compute_is_received", store=True
    )

    @api.depends("state", "order_line.qty_received")
    def _compute_is_received(self):
        for purchase in self:
            picking = self.env["stock.picking"].search([("origin", "=", purchase.name)])
            if picking:
                purchase.is_received = any(pick.state == "done" for pick in picking)

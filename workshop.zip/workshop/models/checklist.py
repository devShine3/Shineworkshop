from datetime import date
from dateutil.relativedelta import relativedelta
from psutil import long

from odoo.exceptions import UserError
from odoo import models, api, fields, _


class Checklist(models.Model):
    _name = "checklist"
    _description = "Car Workshop checklist"
    _inherit = ["mail.thread"]

    def _get_default_vehicle_ids(self):
        default_vehicle_id = self.env["fleet.vehicle"].browse(
            self._context.get("active_id")
        )
        return default_vehicle_id

    car_id = fields.Many2one("fleet.vehicle", string="Vehicle", index=True)
    name = fields.Char(string="Title", track_visibility="onchange", required=True)
    part_yes = fields.Boolean(string="Yes", default=False)
    part_no = fields.Boolean(string="No", default=False)
    condition_good = fields.Boolean(string="Good", default=True)
    condition_bad = fields.Boolean(string="Bad", default=True)
    remark = fields.Char(string="Remark")
    partner_id = fields.Many2one(
        "res.partner", "Customer", tracking=True, help="Workshop Customers", copy=False
    )

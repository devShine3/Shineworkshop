from odoo import _, api, fields, models
from odoo.exceptions import UserError
from odoo.tools.float_utils import float_compare


class WorkshopInventory(models.Model):
    _inherit = "stock.quant"

    inventory_date = fields.Date(
        "Scheduled Date",
        compute="_compute_inventory_date",
        store=True,
        readonly=False,
        help="Next date the On Hand Quantity should be counted.",
    )

    @api.model
    def create(self, vals):
        """Override to handle the "inventory mode" and create a quant as
        superuser the conditions are met.
        """
        if self._is_inventory_mode() and any(
            f in vals for f in ["inventory_quantity", "inventory_quantity_auto_apply"]
        ):
            allowed_fields = self._get_inventory_fields_create()
            # if any(field for field in vals.keys() if field not in allowed_fields):
            #     raise UserError(_("Quant's creation is restricted, you can't do this operation."))

            auto_apply = "inventory_quantity_auto_apply" in vals
            inventory_quantity = (
                vals.pop("inventory_quantity_auto_apply", False)
                or vals.pop("inventory_quantity", False)
                or 0
            )
            # Create an empty quant or write on a similar one.
            product = self.env["product.product"].browse(vals["product_id"])
            location = self.env["stock.location"].browse(vals["location_id"])
            lot_id = self.env["stock.production.lot"].browse(vals.get("lot_id"))
            package_id = self.env["stock.quant.package"].browse(vals.get("package_id"))
            owner_id = self.env["res.partner"].browse(vals.get("owner_id"))
            quant = self.env["stock.quant"]

            save_by_backdate = (
                self.env["ir.config_parameter"]
                .sudo()
                .get_param("workshop.save_by_backdate")
            )
            save_by_backdate = save_by_backdate == "True"

            if not self.env.context.get("import_file"):
                # Merge quants later, to make sure one line = one record during batch import
                quant = self._gather(
                    product,
                    location,
                    lot_id=lot_id,
                    package_id=package_id,
                    owner_id=owner_id,
                    strict=True,
                )

            if lot_id:
                quant = quant.filtered(lambda q: q.lot_id)

            if quant:
                quant = quant[0].sudo()
            else:
                quant = self.sudo().create(vals)
            if auto_apply:
                quant.write({"inventory_quantity_auto_apply": inventory_quantity})
            else:
                # Set the `inventory_quantity` field to create the necessary move.
                quant.inventory_quantity = inventory_quantity
                quant.user_id = vals.get("user_id", self.env.user.id)

                if save_by_backdate == False:
                    quant.inventory_date = fields.Date.today()

            return quant
        res = super(WorkshopInventory, self).create(vals)
        if self._is_inventory_mode():
            res._check_company()
        return res

    @api.model
    def _get_inventory_fields_create(self):
        """Returns a list of fields user can edit when he want to create a quant in `inventory_mode`."""
        return [
            "product_id",
            "location_id",
            "lot_id",
            "package_id",
            "owner_id",
        ] + self._get_inventory_fields_write()

    @api.model
    def _get_inventory_fields_write(self):
        """Returns a list of fields user can edit when he want to edit a quant in `inventory_mode`."""
        fields = [
            "inventory_quantity",
            "inventory_quantity_auto_apply",
            "inventory_diff_quantity",
            "inventory_date",
            "user_id",
            "inventory_quantity_set",
            "is_outdated",
        ]
        return fields

    @api.depends("location_id")
    def _compute_inventory_date(self):
        save_by_backdate = (
            self.env["ir.config_parameter"]
            .sudo()
            .get_param("workshop.save_by_backdate")
        )
        save_by_backdate = save_by_backdate == "True"

        if save_by_backdate == False:
            quants = self.filtered(
                lambda q: not q.inventory_date
                and q.location_id.usage in ["internal", "transit"]
            )
            date_by_location = {
                loc: loc._get_next_inventory_date() for loc in quants.location_id
            }
            for quant in quants:
                quant.inventory_date = date_by_location[quant.location_id]
        return

    def _apply_inventory(self):
        move_vals = []
        if not self.user_has_groups("stock.group_stock_manager"):
            raise UserError(
                _("Only a stock manager can validate an inventory adjustment.")
            )
        for quant in self:
            # Create and validate a move so that the quant matches its `inventory_quantity`.
            if (
                float_compare(
                    quant.inventory_diff_quantity,
                    0,
                    precision_rounding=quant.product_uom_id.rounding,
                )
                > 0
            ):
                move_vals.append(
                    quant._get_inventory_move_values(
                        quant.inventory_diff_quantity,
                        quant.product_id.with_company(
                            quant.company_id
                        ).property_stock_inventory,
                        quant.location_id,
                    )
                )
            else:
                move_vals.append(
                    quant._get_inventory_move_values(
                        -quant.inventory_diff_quantity,
                        quant.location_id,
                        quant.product_id.with_company(
                            quant.company_id
                        ).property_stock_inventory,
                        out=True,
                    )
                )
        moves = (
            self.env["stock.move"].with_context(inventory_mode=False).create(move_vals)
        )
        moves._action_done()
        self.location_id.write({"last_inventory_date": fields.Date.today()})

        save_by_backdate = (
            self.env["ir.config_parameter"]
            .sudo()
            .get_param("workshop.save_by_backdate")
        )
        save_by_backdate = save_by_backdate == "True"

        if save_by_backdate == False:
            date_by_location = {
                loc: loc._get_next_inventory_date()
                for loc in self.mapped("location_id")
            }
            for quant in self:
                quant.inventory_date = date_by_location[quant.location_id]

        self.write({"inventory_quantity": 0, "user_id": False})
        self.write({"inventory_diff_quantity": 0})

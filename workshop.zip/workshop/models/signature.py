from odoo import models, fields


class Signature(models.Model):
    _name = "workshop.signature"
    _description = "Signature"

    sign = fields.Binary(string="Signature")

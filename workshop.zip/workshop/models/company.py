from odoo import models, fields

class WorkshopCompany(models.Model):
    _inherit = "res.company"

    location_id = fields.Many2one('stock.location', string="Warehouse Location")

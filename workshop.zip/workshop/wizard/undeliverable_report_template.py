from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class UndeliverableReport(models.TransientModel):
    _name = "undeliverable.report.wizard"
    _description = "Undeliverable Report"

    car_id = fields.Many2one("fleet.vehicle", string="Vehicle")
    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")

    def check_report(self):
        data = {}
        data["form"] = self.read(["car_id", "date_from", "date_to"])[0]
        return (
            self.env.ref("workshop.action_undeliverable_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    # def action_print_undeliverable_report(self):
    #     data = {}
    #     data['form'] = self.read(
    #         ['car_id', 'date_from', 'date_to']
    #     )[0]
    #     return self.env.ref('workshop.action_undeliverable_report_template').report_action(self, data=data)

from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class WorksheetDetailReport(models.TransientModel):
    _name = "worksheet.detail.report.wizard"
    _description = "Worksheet Detail Report"

    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")
    car_id = fields.Many2one("fleet.vehicle", string="Vehicle")
    stages = fields.Many2one("worksheet.stages", string="Worksheet Stage")

    def check_report(self):
        data = {}
        data["form"] = self.read(["date_from", "date_to", "car_id", "stages"])[0]
        return (
            self.env.ref("workshop.action_worksheet_detail_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )
    # def action_print_worksheet_detial_report(self):
    #     data = {}
    #     data["form"] = self.read(["date_from", "date_to", "car_id"])[0]
    #     return self.env.ref(
    #         "workshop.action_worksheet_detail_report_template"
    #     ).report_action(self, data=data)

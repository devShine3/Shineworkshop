from odoo import models, fields, api, _


class InOutDailyReport(models.TransientModel):
    _name = "in.out.daily.report.wizard"
    _description = "In Out Daily Report"

    worksheet_type = fields.Selection(
        string="Worksheet Type",
        selection=[("bp", "BP"), ("gr", "GR"), ("all", "All")],
        default="bp",
    )

    date_for = fields.Date(string="Date", default=fields.Date.context_today)

    def action_print_inout_daily(self):
        data = {
            "form": self.read(["worksheet_type", "date_for"])[0],
            "today": fields.Date.context_today(self),
        }
        return self.env.ref("workshop.action_inout_daily_template").report_action(
            self, data=data
        )

from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ComeBackReport(models.TransientModel):
    _name = "comeback.report.wizard"
    _description = "Come Back Job Report"

    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")
    car_id = fields.Many2one("fleet.vehicle", string="Vehicle")

    def check_report(self):
        data = {}
        data["form"] = self.read(["date_from", "date_to", "car_id"])[0]
        return (
            self.env.ref("workshop.action_comeback_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    # def action_print_comeback_report(self):
    #     data = {}
    #     data['form'] = self.read(
    #         ['date_from', 'date_to', 'car_id']
    #     )[0]
    #     return self.env.ref('workshop.action_comeback_report_template').report_action(self, data=data)

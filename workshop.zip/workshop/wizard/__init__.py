# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


from . import checklist_report_template
from . import undeliverable_report_template
from . import worksheet_detail_report_template
from . import come_back_job_report_template
from . import in_out_daily_report

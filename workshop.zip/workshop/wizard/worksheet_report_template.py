from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class WorksheetReport(models.TransientModel):
    _name = "worksheet.report.wizard"
    _description = "Worksheet Report"

    car_id = fields.Many2one("fleet.vehicle", string="Vehicle")
    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")

    def check_report(self):
        data = {}
        data["form"] = self.read(["date_from", "date_to", "car_id"])[0]
        return (
            self.env.ref("workshop.action_undeliverable_report_template")
            .with_context(landscape=True)
            .report_action(self, data=data)
        )

    # def action_print_worksheet_report(self):
    #     data = {}
    #     data["form"] = self.read(["car_id", "date_from", "date_to"])[0]
    #     return self.env.ref(
    #         "workshop.action_undeliverable_report_template"
    #     ).with_context(landscape=True).report_action(self, data=data)


from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ChecklistReport(models.TransientModel):
    _name = "checklist.report.wizard"
    _description = "Workshop Vehicle Checklist Report"

    car_id = fields.Many2one("fleet.vehicle", string="Vehicle", required=1)
    car_checklist = fields.Many2one(
        "workshop.checklist", string="Checklist", required=1
    )

    date_from = fields.Date(string="From")
    date_to = fields.Date(string="To")
    report_date = fields.Datetime("Report Date :", default=date.today())

    def action_print_checklist_report(self):
        data = {}
        data["form"] = self.read(
            ["car_id", "car_checklist", "date_from", "date_to", "report_date"]
        )[0]
        return self.env.ref("workshop.action_checklist_report_template").report_action(
            self, data=data
        )

    def custom_print(self, data):
        return self.env.ref("workshop.action_checklist_report_template").report_action(
            self, data=data
        )

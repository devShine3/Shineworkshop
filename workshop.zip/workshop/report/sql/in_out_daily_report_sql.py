TAG_SQL = """
SELECT DISTINCT rc.id, rc.name
FROM fleet_vehicle fv
JOIN res_partner rp ON fv.partner_id = rp.id
JOIN res_partner_res_partner_category_rel rprcl ON rp.id = rprcl.partner_id
JOIN res_partner_category rc ON rprcl.category_id = rc.id
WHERE fv.partner_id IS NOT NULL ORDER BY rc.name;
"""

IN_OUT_QUERY = """
SELECT COUNT(DISTINCT cw.id)
FROM car_workshop cw
LEFT JOIN res_partner rp ON cw.partner_id = rp.id
LEFT JOIN res_partner_res_partner_category_rel rprcl ON rp.id = rprcl.partner_id
LEFT JOIN res_partner_category rc ON rprcl.category_id = rc.id
LEFT JOIN car_workshop_workshop_tag_rel cwt ON cw.id = cwt.car_workshop_id
LEFT JOIN workshop_tag wt ON cwt.workshop_tag_id = wt.id
LEFT JOIN fleet_vehicle fv ON fv.id = cw.vehicle_id
LEFT JOIN fleet_vehicle_state fvs ON fv.state_id = fvs.id
LEFT JOIN worksheet_stages ws ON cw.stage_id = ws.id
LEFT JOIN car_record cr ON cr.vehicle_id = cw.vehicle_id
WHERE rc.id = %d
"""

IN_DAY = "AND (cw.create_date::date = '%s' OR cr.create_date::date = '%s')"
OUT_DAY = "AND (cw.create_date::date = '%s' OR cr.create_date::date = '%s') AND ws.finishing_state = True AND fvs.finishing_state = True"
IN_MONTH = "AND ((cw.create_date::date BETWEEN '%s' AND '%s') OR (cr.create_date::date BETWEEN '%s' AND '%s'))"
OUT_MONTH = "AND ((cw.create_date::date BETWEEN '%s' AND '%s') OR (cr.create_date::date BETWEEN '%s' AND '%s')) AND ws.finishing_state = True AND fvs.finishing_state = True"

from odoo import http, models, api, _
from odoo.exceptions import UserError
from bs4 import BeautifulSoup


class ReportWorksheetDetail(models.AbstractModel):
    _name = "report.workshop.report_worksheet_detail"
    _description = "Workshop Worksheet Detail Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_details(data.get("form")),
        }
    
    @api.model
    def get_details(self, options):
        groups = {
            "worksheet": [],
        }
        sql = """
                SELECT
                    cw.create_date,
                    fvm.name AS model_name,
                    fv.license_plate AS fleet_vehicle_name,
                    pt.name AS product_template_name,
                    cw.name AS car_workshop_name,
                    cw.description AS car_workshop_description,
                    cw.id
                FROM
                    car_workshop cw
                LEFT JOIN
                    fleet_vehicle fv ON fv.id = cw.vehicle_id
                LEFT JOIN
                    fleet_vehicle_model fvm ON fvm.id = fv.model_id
                LEFT JOIN
                    res_partner rp ON rp.id = cw.partner_id
                LEFT JOIN
                    planned_work pw ON pw.work_id = cw.id
                LEFT JOIN
                    product_product pp ON pp.id = pw.planned_work
                LEFT JOIN
                    product_template pt ON pt.id = pp.product_tmpl_id
                WHERE
                    cw.id IS NOT NULL
            """

        if options["date_from"] and options["date_to"]:
            sql += """ AND (Date(cw.create_date) BETWEEN '%s' AND '%s') """ % (
                options["date_from"],
                options["date_to"],
            )

        elif options["date_from"]:
            sql += """ AND Date(cw.create_date)='%s' """ % options["date_from"]

        elif options["date_to"]:
            sql += """ AND Date(cw.create_date)='%s' """ % options["date_to"]

        if options["car_id"]:
            sql += " AND cw.vehicle_id = %s " % options["car_id"][0]

        if options["stages"]:
            sql += " AND cw.stage_id = %s " % options["stages"][0]

        sql += " ORDER BY cw.create_date ASC"

        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()
        cw = {}
        seen_worksheet = set()
        text_description = ""
        for result in results:
            worksheet_name = result[6]
            if worksheet_name not in seen_worksheet:
                if result[5]:
                    soup = BeautifulSoup(result[5], "html.parser")
                    text_description = soup.get_text()

                    planned_works = self.env['planned.work'].search([('work_id', '=', result[6])])
                    planned_work_text = ', '.join(planned_works.planned_work.mapped('name'))
                cw = {
                    'Date': result[0],
                    'ModelName': result[1],
                    'LicensePlate': result[2],
                    'ProductPlanned': planned_work_text,
                    'Title': result[4],
                    'Description': text_description
                    }
                seen_worksheet.add(worksheet_name)
                groups['worksheet'].append(cw)
        return groups
        # report_data = data["form"]

        # worksheet_filter = []
        # if report_data["date_from"]:
        #     worksheet_filter.append(("create_date", ">=", report_data["date_from"]))

        # if report_data["date_to"]:
        #     worksheet_filter.append(("create_date", "<=", report_data["date_to"]))

        # if report_data["car_id"]:
        #     worksheet_filter.append(("vehicle_id", "=", report_data["car_id"][0]))

        # worksheet_record = http.request.env["car.workshop"].search(worksheet_filter)
        # model_record = http.request.env["fleet.vehicle.model"].search(["vehicle_id", "=", ""])
        # worksheet_detail_records = []
        # for worksheet in worksheet_record:
        #     worksheet_detail_record = {
        #         "date": worksheet["create_date"],
        #         "car": worksheet["vehicle_id"][""],
        #         "customer": worksheet["partner_id"]["name"],
        #         "description": worksheet["description"],
        #         "stage": worksheet["stage_id"]["name"],
        #     }
        #     worksheet_detail_records.append(worksheet_detail_record)

        # template_record = {"worksheet_detail": worksheet_detail_records}
        # print(template_record)

        # return {"data": report_data, "lines": template_record}

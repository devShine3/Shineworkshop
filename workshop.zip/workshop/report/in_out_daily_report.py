# -*- coding: utf-8 -*-
import datetime
import logging
from dataclasses import dataclass
from typing import List, Optional, Dict, Any
from odoo import models, api, _
from odoo.exceptions import UserError
from odoo import models, api
from .sql.in_out_daily_report_sql import (
    TAG_SQL,
    IN_OUT_QUERY,
    IN_DAY,
    IN_MONTH,
    OUT_DAY,
    OUT_MONTH,
)

_logger = logging.getLogger(__name__)


@dataclass
class QueryData:
    extend_query: str
    customer_tag_id: int
    start_date: str
    worksheet_tag: Optional[int] = None
    end_date: Optional[str] = None
    stage_id: Optional[int] = None


class InOutDailyReport(models.AbstractModel):
    _name = "report.workshop.report_inout_daily_template"
    _description = "In Out Daily Report"

    @api.model
    def _get_report_values(self, docids, data=None) -> Dict:
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data,
            "lines": self.get_lines(data),
        }

    def _get_stage(self):
        return self.env["worksheet.stages"].search([], limit=1, order="sequence").id

    @staticmethod
    def _get_date_obj(today: str) -> Dict:
        date_obj = datetime.datetime.strptime(today, "%Y-%m-%d")
        # Calculate the start date of the current month
        current_month_start = datetime.date(date_obj.year, date_obj.month, 1)

        # Calculate the end date of the current month
        if date_obj.month == 1:
            next_month_year = date_obj.year
            next_month = 2
        else:
            next_month_year = date_obj.year
            next_month = date_obj.month + 1

        if next_month == 13:
            next_month = 1
            next_month_year += 1

        current_month_end = datetime.date(
            next_month_year, next_month, 1
        ) - datetime.timedelta(days=1)

        # Calculate the start date of the last month
        last_month_start_date = (
            datetime.date(date_obj.year, date_obj.month - 1, 1)
            if date_obj.month > 1
            else datetime.date(date_obj.year - 1, 12, 1)
        )

        # Calculate the end date of the last month
        last_month_end_date = current_month_start - datetime.timedelta(days=1)
        return {
            "current_month_start": current_month_start,
            "current_month_end": current_month_end,
            "last_month_start_date": last_month_start_date,
            "last_month_end_date": last_month_end_date,
        }

    @staticmethod
    def _prepare_query(data: QueryData) -> str:
        update_query = IN_OUT_QUERY + data.extend_query
        if not data.end_date:
            update_query %= (
                data.customer_tag_id,
                data.start_date,
                data.start_date,
            )
        elif data.end_date:
            update_query %= (
                data.customer_tag_id,
                data.start_date,
                data.end_date,
                data.start_date,
                data.end_date,
            )
        # if not data.worksheet_tag:
        #     update_query += " AND wt.id IS NOT NULL"
        if data.worksheet_tag:
            update_query += " AND wt.id=%d" % (data.worksheet_tag)
        # if data.stage_id:
        #     update_query += " AND (cw.stage_id= %d OR cr.stage_id=%d)" % (
        #         data.stage_id,
        #         data.stage_id,
        #     )

        return update_query

    @api.model
    def get_lines(self, options) -> Dict:
        line_data = {
            "result": {
                "tag_count": [],
                "total": [],
            }
        }
        total_today_in = 0
        total_today_out = 0
        total_month_in = 0
        total_month_out = 0
        total_last_in = 0
        total_last_out = 0

        # Get Tag Names
        self.env.cr.execute(TAG_SQL)
        result = self.env.cr.fetchall()

        # BP or GR
        tag_id = None
        if options["form"].get("worksheet_type") == "bp":
            tag_id = 1
        if options["form"].get("worksheet_type") == "gr":
            tag_id = 2

        today_date = options["form"].get("date_for")
        date_dict = self._get_date_obj(today=today_date)

        today_incount = 0
        today_outcount = 0
        this_month_incount = 0
        this_month_outcount = 0
        last_month_incount = 0
        last_month_outcount = 0

        in_out_list = []
        for record in result:
            today_in_query = self._prepare_query(
                QueryData(
                    extend_query=IN_DAY,
                    customer_tag_id=record[0],
                    worksheet_tag=tag_id,
                    start_date=today_date,
                    stage_id=self._get_stage(),
                )
            )
            self.env.cr.execute(today_in_query)
            today_inresult = self.env.cr.fetchall()
            today_incount = today_inresult[0][0]
            total_today_in += today_incount

            today_out_query = self._prepare_query(
                QueryData(
                    extend_query=OUT_DAY,
                    customer_tag_id=record[0],
                    worksheet_tag=tag_id,
                    start_date=today_date,
                )
            )
            self.env.cr.execute(today_out_query)
            today_outresult = self.env.cr.fetchall()
            today_outcount = today_outresult[0][0]
            total_today_out += today_outcount

            this_month_in_query = self._prepare_query(
                QueryData(
                    extend_query=IN_MONTH,
                    customer_tag_id=record[0],
                    worksheet_tag=tag_id,
                    start_date=date_dict["current_month_start"],
                    end_date=date_dict["current_month_end"],
                    stage_id=self._get_stage(),
                )
            )
            self.env.cr.execute(this_month_in_query)
            month_inresult = self.env.cr.fetchall()
            this_month_incount = month_inresult[0][0]
            total_month_in += this_month_incount

            this_month_out_query = self._prepare_query(
                QueryData(
                    extend_query=OUT_MONTH,
                    customer_tag_id=record[0],
                    worksheet_tag=tag_id,
                    start_date=date_dict["current_month_start"],
                    end_date=date_dict["current_month_end"],
                )
            )
            self.env.cr.execute(this_month_out_query)
            month_outresult = self.env.cr.fetchall()
            this_month_outcount = month_outresult[0][0]
            total_month_out += this_month_outcount

            last_month_in_query = self._prepare_query(
                QueryData(
                    extend_query=IN_MONTH,
                    customer_tag_id=record[0],
                    worksheet_tag=tag_id,
                    start_date=date_dict["last_month_start_date"],
                    end_date=date_dict["last_month_end_date"],
                    stage_id=self._get_stage(),
                )
            )
            self.env.cr.execute(last_month_in_query)
            lastmonth_inresult = self.env.cr.fetchall()
            last_month_incount = lastmonth_inresult[0][0]
            total_last_in += last_month_incount

            last_month_out_query = self._prepare_query(
                QueryData(
                    extend_query=OUT_MONTH,
                    customer_tag_id=record[0],
                    worksheet_tag=tag_id,
                    start_date=date_dict["last_month_start_date"],
                    end_date=date_dict["last_month_end_date"],
                )
            )
            self.env.cr.execute(last_month_out_query)
            lastmonth_outresult = self.env.cr.fetchall()
            last_month_outcount = lastmonth_outresult[0][0]
            total_last_out += last_month_outcount

            # Prepare In Out Count Row
            in_out_vals = {
                "tag": record[1],
                "today_incount": today_incount,
                "today_outcount": today_outcount,
                "this_month_incount": this_month_incount,
                "this_month_outcount": this_month_outcount,
                "last_month_incount": last_month_incount,
                "last_month_outcount": last_month_outcount,
            }
            in_out_list.append(in_out_vals)  # In Out Count Array

        total_list = {
            "total_today_in": total_today_in,
            "total_today_out": total_today_out,
            "total_month_in": total_month_in,
            "total_month_out": total_month_out,
            "total_last_in": total_last_in,
            "total_last_out": total_last_out,
        }
        # Each tag count
        line_data["result"]["tag_count"].extend(in_out_list)
        # Total Count
        line_data["result"]["total"].append(total_list)

        return line_data

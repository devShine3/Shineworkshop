from odoo import models, api, _
from odoo.exceptions import UserError
from bs4 import BeautifulSoup


class ReportUndeliverable(models.AbstractModel):
    _name = "report.workshop.report_undeliverable"
    _description = "Workshop Undeliverable Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_details(data.get("form")),
        }

    @api.model
    def get_details(self, options):
        groups = {
            "undeliverable": [],
        }
        sql = """
                select fv.name,fv.license_plate,rp.name,cw.date_assign,fvs.name,cw.description,cw.id
                from car_workshop cw
                join fleet_vehicle fv on fv.id = cw.vehicle_id
                join res_partner rp on rp.id = cw.partner_id
                join fleet_vehicle_state fvs on fvs.id = fv.state_id
                join worksheet_stages ws on ws.id = cw.stage_id
                where cw.id is not null
                and ws.finishing_state = True
                and fvs.finishing_state = True
                and cw.car_delivered = False
            """

        if options["car_id"]:
            sql += " AND cw.vehicle_id = %s " % options["car_id"][0]

        if options["date_from"] and options["date_to"]:
            sql += """ AND (Date(cw.date_assign) BETWEEN '%s' AND '%s') """ % (
                options["date_from"],
                options["date_to"],
            )

        elif options["date_from"]:
            sql += """ AND Date(cw.date_assign)='%s' """ % options["date_from"]

        elif options["date_to"]:
            sql += """ AND Date(cw.date_assign)='%s' """ % options["date_to"]

        sql += " ORDER BY cw.date_assign ASC"

        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()
        total = 0
        total_amount = 0
        under = {}
        text_description = ""
        for result in results:
            total = self.env["car.workshop"].sudo().search([("id", "=", result[6])])
            if total:
                total_amount = total.amount_total
            if result[5]:
                soup = BeautifulSoup(result[5], 'html.parser')
                text_description = soup.get_text()
            under = {'VehicleName': result[0],
                    'LicensePlate': result[1],
                    'CustomerName': result[2],
                    'DateAssign': result[3],
                    'StateName': result[4],
                    'Description': text_description,
                    'Total': total_amount
                    }
            groups['undeliverable'].append(under)
        return groups

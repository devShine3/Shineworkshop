from odoo import http, models, api, _
from odoo.exceptions import UserError
from bs4 import BeautifulSoup


class ReportComeback(models.AbstractModel):
    _name = "report.workshop.report_comeback"
    _description = "Workshop Comeback Job Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )
        return {
            "data": data["form"],
            "lines": self.get_details(data.get("form")),
        }

    @api.model
    def get_details(self, options):
        groups = {
            "comeback": [],
        }
        sql = """
                SELECT
                    cw.create_date,
                    fvm.name AS model_name,
                    fv.license_plate AS fleet_vehicle_name,
                    pt.name AS product_template_name,
                    cw.name AS car_workshop_name,
                    cw.description AS car_workshop_description,
                    cw.id
                FROM
                    comeback_job cj
                LEFT JOIN
                    fleet_vehicle fv ON fv.id = cj.vehicle_id
                LEFT JOIN
                    fleet_vehicle_model fvm ON fvm.id = fv.model_id
                LEFT JOIN
                    res_partner rp ON rp.id = cj.partner_id
                LEFT JOIN
                    fleet_vehicle_state fvs ON fvs.id = fv.state_id
                LEFT JOIN
                    car_workshop cw ON cw.vehicle_id = fv.id
                LEFT JOIN
                    planned_work pw ON pw.work_id = cw.id
                LEFT JOIN
                    product_product pp ON pp.id = pw.planned_work
                LEFT JOIN
                    product_template pt ON pt.id = pp.product_tmpl_id
                WHERE
                    cj.id IS NOT NULL
                AND cj.comeback_job = 'True'
                AND cw.comeback_job = 'True'
            """

        if options["date_from"] and options["date_to"]:
            sql += """ AND (Date(cw.create_date) BETWEEN '%s' AND '%s') """ % (
                options["date_from"],
                options["date_to"],
            )

        elif options["date_from"]:
            sql += """ AND Date(cw.create_date)='%s' """ % options["date_from"]

        elif options["date_to"]:
            sql += """ AND Date(cw.create_date)='%s' """ % options["date_to"]

        if options["car_id"]:
            sql += " AND cj.vehicle_id = %s " % options["car_id"][0]

        sql += " ORDER BY cw.create_date ASC"

        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()
        cj = {}
        seen_comeback = set()
        text_description = ""
        for result in results:
            comeback_name = result[6]
            if comeback_name not in seen_comeback:
                if result[5]:
                    soup = BeautifulSoup(result[5], "html.parser")
                    text_description = soup.get_text()

                    planned_works = self.env['planned.work'].search([('work_id', '=', result[6])])
                    planned_work_text = ', '.join(planned_works.planned_work.mapped('name'))
                cj = {
                    'Date': result[0],
                    'ModelName': result[1],
                    'LicensePlate': result[2],
                    'ProductPlanned': planned_work_text,
                    'Title': result[4],
                    'Description': text_description
                    }
                seen_comeback.add(comeback_name)
                groups['comeback'].append(cj)
        return groups

# -*- coding: utf-8 -*-
from datetime import time
from odoo import http, models, api, _
from odoo.exceptions import UserError


class ReportChecklist(models.AbstractModel):
    _name = "report.workshop.report_checklist_details"
    _description = "Workshop Vehicle Checklist Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        if not data.get("form"):
            raise UserError(
                _("Form content is missing, this report cannot be printed.")
            )

        report_data = data["form"]

        filter = [("id", "=", report_data["car_checklist"][0])]

        record = http.request.env["workshop.checklist"].search(filter)
        main_record = record

        check_records = self.get_lines(report_data)

        car_check = []
        for check in main_record["car_check"]:
            check_record = {
                "name": check.name,
                "exists": check.exists,
                "working": check.working,
                "remark": check.remark,
            }
            car_check.append(check_record)

        template_record = {
            "check": car_check,  # check_records['check'],
            "sign": main_record["sign"],
            "owner_sign": main_record["owner_sign"],
            "notes": main_record["notes"],
        }

        return {"data": report_data, "lines": template_record}

    @api.model
    def get_lines(self, options):
        groups = dict((tp, []) for tp in ["check"])

        # moves = {}

        # sql = '''
        #     select c.name,c.part_yes,c.part_no,c.condition_good,
        #     c.condition_bad,c.remark,c.car_id,v.license_plate,vm.name,vmb.name,c.create_date
        #     from checklist c
        #     join fleet_vehicle v on c.car_id=v.id
        #     join fleet_vehicle_model vm on v.model_id=vm.id
        #     join fleet_vehicle_model_brand vmb on vm.brand_id=vmb.id
        #     where c.id is not null
        #  '''

        sql = """
                SELECT v.name, v.license_plate, v.id AS car_id,
                json_agg(
                    json_build_object(
                        'name', c.name,
                        'exists', c.exists,
                        'working', c.working,
                        'remark', c.remark
                    )
                ) AS checklist, l.id AS checklist_id
                FROM workshop_car_check c
                JOIN workshop_checklist l ON c.checklist = l.id
                JOIN fleet_vehicle v ON l.car_id = v.id
            """

        # if options['car_id']:
        # sql = sql + ''' and c.car_id = %s ''' % options['car_id'][0]
        # sql += ''' AND v.id = %s ''' % options['car_id'][0]
        # if options['date_from']:
        #     sql = sql + '''and c.create_date >= '%s'  ''' % options['date_from']
        # if options['date_to']:
        #     sql = sql + '''and c.create_date <= '%s'  ''' % options['date_to']

        if options["car_checklist"]:
            sql += "WHERE "
            sql += """l.id = %s """ % options["car_checklist"][0]

        sql += """ GROUP BY v.id, l.id"""

        if (
            not options["car_id"]
            and not options["date_from"]
            and not options["date_from"]
        ):
            sql = """
                select c.name,c.part_yes,c.part_no,c.condition_good,
                c.condition_bad,c.remark,v.license_plate,vm.name,vmb.name,c.create_date,rp.name
                from checklist c
                join fleet_vehicle v on c.car_id=v.id
                join fleet_vehicle_model vm on v.model_id=vm.id
                join fleet_vehicle_model_brand vmb on vm.brand_id=vmb.id
                join res_partner rp on v.partner_id=rp.id
                where c.id is not null
            """

        self.env.cr.execute(sql)
        results = self.env.cr.fetchall()

        if results:
            #    for result in results:
            #         moves = {'cname': result[0], 'part_yes': result[1], 'part_no': result[2], 'condition_good': result[3],
            #                  'condition_bad': result[4],
            #                  'remark': result[5], 'lp': result[6], 'model': result[7], 'brand': result[8],
            #                  'cd': result[9], 'customer': result[10], }
            #         groups['check'].append(moves)

            result = results[0]
            checklist_container = result[3]

            for check in checklist_container:
                groups["check"].append(check)

        return groups

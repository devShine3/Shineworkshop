from odoo import http, models, api, _


class ReportWorksheet(models.Model):
    _name = "report.workshop.report_worksheet"
    _description = "Worksheet Report"

from odoo import http, SUPERUSER_ID, _
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import (
    ValidationError,
    AccessError,
    MissingError,
    UserError,
    AccessDenied,
)
from odoo.http import request, content_disposition
import re


class WorkshopCustomerPortal(CustomerPortal):
    def _prepare_home_portal_values(self, counters):
        values = super(WorkshopCustomerPortal, self)._prepare_home_portal_values(
            counters
        )
        values["checklist_count"] = request.env["workshop.checklist"].search_count([])
        return values

    def _checklist_get_page_view_values(self, checklist, access_token, **kwargs):
        values = {
            "page_name": "checklist",
            "checklist": checklist,
        }
        checklist_values = self._get_page_view_values(
            checklist, access_token, values, "my_checklists_history", False, **kwargs
        )
        return self._get_page_view_values(
            checklist, access_token, values, "my_checklists_history", False, **kwargs
        )

    @http.route(["/my/checklists"], type="http", website=True)
    def checklists_list_view(self, **kw):
        checklists = request.env["workshop.checklist"].search([])
        checklists_data = []

        for checklist in checklists:
            check_record = {
                "id": checklist["id"],
                "checklist": checklist["display_name"],
                "car_id": checklist["car_id"]["id"],
                "date_time": checklist["date_time"],
                "notes": checklist["notes"],
                "car_check": str(len(list(checklist["car_check"]))) + " record(s)",
            }
            checklists_data.append(check_record)

        values = {"checklists": checklists_data, "page_name": "checklists_list"}

        return request.render("workshop.checklist_portal_list", values)

    # @http.route(["/my/checklists/<model('workshop.checklist'):checklist_id>"], type="http", website=True)
    # def checklists_form_view(self, checklist_id, **kw):
    #     print("checklists_form_view")
    #     checklist = checklist_id
    #     values = {
    #         "checklist": checklist,
    #         'page_name': 'checklists_form'
    #     }

    #     return request.render('workshop.checklist_portal_form', values)

    @http.route(
        ["/my/checklists/<int:checklist_id>"], type="http", auth="public", website=True
    )
    def portal_my_checklist_detail(
        self, checklist_id, access_token=None, report_type=None, download=False, **kw
    ):
        try:
            checklist_sudo = self._document_check_access(
                "workshop.checklist", checklist_id, access_token
            )
        except (AccessError, MissingError):
            return request.redirect("/my")

        company = request.env.company

        if report_type in ("html", "pdf", "text"):
            return self._show_report(
                model=checklist_sudo,
                report_type=report_type,
                report_ref="workshop.workshop_checklists",
                download=download,
            )
            # report_records.download_report()

        report_records = (
            request.env["workshop.checklist"].sudo().search([("id", "=", checklist_id)])
        )

        car_check = []
        for check in report_records["car_check"]:
            check_record = {
                "name": check.name,
                "exists": check.exists,
                "working": check.working,
                "remark": check.remark,
            }
            car_check.append(check_record)

        values = self._checklist_get_page_view_values(
            checklist_sudo, access_token, **kw
        )
        values["data"] = {
            "car_id": [
                report_records["car_id"]["id"],
                report_records["car_id"]["name"],
            ],
            "car_checklist": [report_records["id"], report_records["display_name"]],
        }
        values["lines"] = {
            "check": car_check,
            "sign": report_records["sign"],
            "owner_sign": report_records["owner_sign"],
            "notes": report_records["notes"],
        }
        values["company"] = company
        values["page_name"] = "checklist_view"

        return request.render("workshop.portal_checklist_page", values)

    @http.route(["/my/checklist_preview"], type="http", auth="user", website=True)
    def checklist_preview(self, **kw):
        report_template = request.env.ref("workshop.report_checklist_details")

        checklist_id = int(kw.get("record_id", 0))
        report_records = (
            request.env["workshop.checklist"].sudo().search([("id", "=", checklist_id)])
        )

        car_check = []
        for check in report_records["car_check"]:
            check_record = {
                "name": check.name,
                "exists": check.exists,
                "working": check.working,
                "remark": check.remark,
            }
            car_check.append(check_record)

        if report_template and report_records:
            return request.render(
                "workshop.portal_checklist_preview",
                {
                    "data": {
                        "car_id": [
                            report_records["car_id"]["id"],
                            report_records["car_id"]["name"],
                        ],
                        "car_checklist": [
                            report_records["id"],
                            report_records["display_name"],
                        ],
                    },
                    "lines": {
                        "check": car_check,
                        "sign": report_records["sign"],
                        "owner_sign": report_records["owner_sign"],
                        "notes": report_records["notes"],
                    },
                },
            )
        else:
            return request.redirect("/my/home")

    @http.route(
        ["/my/checklists/download/<model('workshop.checklist'):checklist_id>"],
        auth="user",
        type="http",
        website=True,
    )
    def checklist_download(self, checklist_id, **kw):
        checklist = checklist_id
        return self._show_checklist_report(
            model=checklist,
            report_type="pdf",
            report_ref="workshop.action_checklist_report_template",
            download=True,
        )

    def _show_checklist_report(self, model, report_type, report_ref, download=False):
        if report_type not in ("html", "pdf", "text"):
            raise UserError(_("Invalid report type: %s", report_type))

        checklist = model

        report_sudo = request.env.ref(report_ref).with_user(SUPERUSER_ID)

        if not isinstance(report_sudo, type(request.env["ir.actions.report"])):
            raise UserError(_("%s is not the reference of a report", report_ref))

        if hasattr(checklist, "company_id"):
            report_sudo = report_sudo.with_company(checklist.company_id)

        method_name = "_render_qweb_%s" % (report_type)
        data = {"report_type": report_type}
        if checklist and checklist["car_id"] and checklist["display_name"]:
            data["form"] = {
                "id": checklist["id"],
                "car_id": (checklist["car_id"]["id"], checklist["car_id"]["name"]),
                "car_checklist": (checklist["id"], checklist["display_name"]),
                "date_from": False,
                "date_to": False,
                "report_date": checklist["display_name"],
            }
        report = getattr(report_sudo, method_name)([checklist.id], data=data)[0]
        reporthttpheaders = [
            (
                "Content-Type",
                "application/pdf" if report_type == "pdf" else "text/html",
            ),
            ("Content-Length", len(report)),
        ]
        if report_type == "pdf" and download:
            # filename = "%s.pdf" % (re.sub('\W+', '-', checklist._get_report_base_filename()))
            filename = "Workshop Vehicle Checklist Report.pdf"
            reporthttpheaders.append(
                ("Content-Disposition", content_disposition(filename))
            )
        return request.make_response(report, headers=reporthttpheaders)
